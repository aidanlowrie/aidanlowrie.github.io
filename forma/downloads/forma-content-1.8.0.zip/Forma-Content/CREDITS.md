# Content credits & licences

Forma contains independently sourced educational maps, diagrams and original history summaries. It is not affiliated with Geomaster or with the institutions cited below.

## Reusable content

Map databases, adapted illustrations and their source notices are separately licensed from the app. Their existing open licences continue to apply. They may be copied, modified and redistributed under those licences; Forma's app terms do not restrict those rights. An unrestricted, editable copy and transformation tools are provided on the [content download page](https://forma-support.aidanlowrie.chatgpt.site/content/).

## Geography

World outlines: Natural Earth, public domain. Subdivision maps: geoBoundaries gbOpen and the named original contributors, under the individual licences recorded in geography-sources.json. Additional data: Ordnance Survey Boundary-Line (Contains OS data © Crown copyright and database right 2026; OGL 3.0), Central Statistics Office Ireland (CC BY 4.0), General Statistics Office Vietnam / OCHA (CC BY 3.0 IGO), and US Census Bureau labels (public domain). Source editions and individual attribution appear in each quiz's Map data panel. Source boundaries may represent older administrative arrangements.

The downloadable content includes the exact edited databases, their original URLs, attribution and licence links. ODbL databases and modifications remain ODbL 1.0; CC BY-SA adaptations retain their recorded share-alike licences. Changes include reprojection, simplification, regrouping and marker overlays.

## Biology and chemistry

Animal cell, plant cell, neuron and digestive diagrams: Mariana Ruiz (LadyofHats), public domain; unlabelled derivatives credited to HoverFly and Vivelefrat where applicable. Brain: Jkwchui, after the National Cancer Institute plate, CC BY-SA 3.0. Heart: Wapcaplet, crop by Yaddah, CC BY-SA 3.0. Helium: Yzmo, CC BY-SA 3.0. Forma's corresponding adaptations are supplied under CC BY-SA 3.0. Original and adapted SVG files, source URLs and licences are included in the content download.

Periodic-table data: Bowserinator and contributors, CC BY-SA 3.0; reduced to selected fields for elements 1–118. Nephron, alveolus and the current functional-group illustrations are original Forma educational schematics. The software code is separate from these licensed resources.

## History

History paragraphs are original summaries. Individual citations identify institutional sources for the events and dates. No museum images or copied article passages are included. The content bundle includes the source register and editorial notes.

## Full notices

FORMA — THIRD-PARTY ATTRIBUTIONS

Natural Earth map data: public domain. https://www.naturalearthdata.com/about/terms-of-use/

Periodic Table JSON by Bowserinator and contributors: CC BY-SA 3.0. The element dataset in this distribution is reduced to selected fields for elements 1–118. https://github.com/Bowserinator/Periodic-Table-JSON


D3
Copyright 2010-2023 Mike Bostock

Permission to use, copy, modify, and/or distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright notice
and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.


TopoJSON client
Copyright 2012-2019 Michael Bostock

Permission to use, copy, modify, and/or distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright notice
and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.


US Atlas
Copyright 2013-2019 Michael Bostock

Permission to use, copy, modify, and/or distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright notice
and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
THIS SOFTWARE.


Periodic Table JSON
## [Creative Commons Attribution-ShareAlike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0)
as [cited by Wikipedia](https://en.wikipedia.org/wiki/Wikipedia:Text_of_Creative_Commons_Attribution-ShareAlike_3.0_Unported_License)

This is a human-readable summary of (and not a substitute for) the
[license](https://creativecommons.org/licenses/by-sa/3.0/legalcode).

This work is licensed under a Creative Commons Attribution-ShareAlike 3.0
Unported License.

### You are free:

- to Share — to copy, distribute and transmit the work, and
- to Remix — to [adapt](https://en.wikipedia.org/wiki/Literary_adaptation) the
  work

### Under the following terms:

- Attribution — You must
  [attribute](https://en.wikipedia.org/wiki/Attribution_(copyright)) the work in
  the manner specified by the author or
  [licensor](https://en.wiktionary.org/wiki/licensor) (but not in any way that
  suggests that they endorse you or your use of the work.)
- ShareAlike — If you alter, transform, or build upon this work, you may
  distribute the resulting work only under the same, similar or a compatible
  license.

### With the understanding that:

- Waiver — Any of the above conditions can be
  [waived](https://en.wikipedia.org/wiki/Waiver) if you get permission from the
  copyright holder.
- Other Rights — In no way are any of the following rights affected by the
  license:
  - your [fair dealing](https://en.wikipedia.org/wiki/Fair_dealing) or
    [fair use](https://en.wikipedia.org/wiki/Fair_use) rights;
  - the author's
    [moral rights](https://en.wikipedia.org/wiki/Moral_rights_(copyright_law));
    and
  - rights other persons may have either in the work itself or in how the work
    is used, such as
    [publicity](https://en.wikipedia.org/wiki/Personality_rights) or
    [privacy](https://en.wikipedia.org/wiki/Privacy_law) rights.
- Notice — For any reuse or distribution, you must make clear to others the
  license terms of this work. The best way to do that is with a link to
  [http://creativecommons.org/licenses/by-sa/3.0](http://creativecommons.org/licenses/by-sa/3.0)


DM Sans
Copyright 2014 The DM Sans Project Authors (https://github.com/googlefonts/dm-fonts)

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
https://scripts.sil.org/OFL


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded, 
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.


Fraunces
Copyright 2018 The Fraunces Project Authors (https://github.com/undercasetype/Fraunces)

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
http://scripts.sil.org/OFL


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded, 
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.



NATIVE SCIENCE ARTWORK

Animal cell — Mariana Ruiz (LadyofHats); unlabelled derivative by HoverFly. Public domain.
https://commons.wikimedia.org/wiki/File:Animal_cell_structure_no_text.svg

Plant cell — Mariana Ruiz (LadyofHats); unlabelled derivative by Vivelefrat. Public domain.
https://commons.wikimedia.org/wiki/File:Plant_cell_structure_no_text-2.svg

Neuron — Mariana Ruiz (LadyofHats). Public domain. Labels and leader lines removed.
https://commons.wikimedia.org/wiki/File:Complete_neuron_cell_diagram_en.svg

Digestive system — Mariana Ruiz (LadyofHats). Public domain. Labels removed and plate cropped.
https://commons.wikimedia.org/wiki/File:Digestive_system_diagram_en.svg

Brain — vectorisation by Jkwchui, after the US National Cancer Institute SEER anatomy plate. CC BY-SA 3.0. Labels removed and plate cropped.
https://commons.wikimedia.org/wiki/File:Cerebrum_lobes.svg

Heart — Wapcaplet; crop by Yaddah. CC BY-SA 3.0. Labels removed and plate cropped.
https://commons.wikimedia.org/wiki/File:Diagram_of_the_human_heart_(cropped).svg

Helium — Yzmo. CC BY-SA 3.0. Electron probability cloud with a magnified schematic nucleus; the nuclear inset is not to scale.
https://commons.wikimedia.org/wiki/File:Helium_atom_QM.svg

The brain, heart, helium illustrations and their adapted SVG/PNG artwork are distributed under CC BY-SA 3.0:
https://creativecommons.org/licenses/by-sa/3.0/
https://creativecommons.org/licenses/by-sa/3.0/legalcode
The adapted vector sources are included in Content/Artwork. The licence applies to these illustrations, not to unrelated application code. No endorsement by the original authors is implied.

Functional groups — original depictions generated from explicit SMILES using RDKit. Ethanol CCO; acetone CC(=O)C; acetic acid CC(=O)O; ethylamine CCN; ethanethiol CCS; methyl acetate CC(=O)OC.
https://www.rdkit.org/docs/GettingStartedInPython.html#drawing-molecules
RDKit is a BSD-licensed build-time tool; it is not included in the application.

Forma 1.4: nephron.svg, alveolus.svg and the replacement groups.svg are original Forma educational vector schematics. Copyright 2026 Forma. Scientific references are listed in SCIENCE-REVISION-1.4.md; no OpenStax figure is reproduced in these plates. Earlier third-party attribution applies to the retained original artwork, not these replacement diagrams.

Forma 1.6 geography: per-layer source and licence records are in geography-sources.json; adapted subdivision databases retain their recorded licences, including ODbL 1.0 and CC BY-SA where applicable. Full notices and licence links: GEOGRAPHY-LICENCES.md. Editable derived datasets are distributed in Content/Boards with Tools/build-geography.py. Contains OS data © Crown copyright and database right 2026. Irish county data: Central Statistics Office, Government of Ireland. Vietnam provinces: General Statistics Office / OCHA. Virginia labels: US Census Bureau TIGERweb.


# Geography data in Forma 1.6

The new subdivision layers retain their original licences independently. `geography-sources.json` gives each board's provider, original contributors, represented year, download URL, licence and licence-source URL. Each board JSON also carries a readable attribution, displayed in the app's Map data panel. No endorsement is implied.

Derived geometry is included in editable JSON/SVG-path form in `Boards/`, alongside its names and identifiers. Forma's modifications are reprojection, simplification, grouping by parent region, joining same-name fragments, and small-area markers. `Tools/build-geography.py` supplies the transformation recipe. The source distribution includes these adapted datasets without access restrictions.

Layers attributed to Open Data Commons Open Database Licence 1.0 are made available, including Forma's modifications, under ODbL 1.0: https://opendatacommons.org/licenses/odbl/1-0/ . Individual contents retain any separate rights identified in their source. This notice applies to the corresponding geographic databases, not unrelated app code.

Layers attributed to Creative Commons Attribution-ShareAlike remain under their corresponding licence, including Forma's adaptations:
- CC BY-SA 2.0: https://creativecommons.org/licenses/by-sa/2.0/
- CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/

Other per-layer terms (consult the manifest for the applicable layer):
- CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
- CC BY 3.0: https://creativecommons.org/licenses/by/3.0/
- CC BY 3.0 IGO: https://creativecommons.org/licenses/by/3.0/igo/
- CC BY 2.5: https://creativecommons.org/licenses/by/2.5/
- CC BY 2.5 India: https://creativecommons.org/licenses/by/2.5/in/
- CC0: https://creativecommons.org/publicdomain/zero/1.0/
- Open Government Licence 3.0: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
- Etalab Open Licence 2.0 and swisstopo: source-specific terms linked in the manifest.

Great Britain ceremonial county data: Contains OS data © Crown copyright and database right 2026. Ordnance Survey Boundary-Line, May 2026, Open Government Licence 3.0.

Ireland county data: Central Statistics Office, Government of Ireland, CC BY 4.0. Northern Ireland context is excluded from the 26-county quiz. The original file has no declared CRS; interpreting its coordinates as Irish Grid EPSG:29903 was checked against county locations before conversion.

Vietnam 2025 provinces: General Statistics Office of Vietnam, distributed by OCHA/HDX under CC BY 3.0 IGO. Adapted from the 34-province boundary dataset.

Virginia county and independent-city labels: US Census Bureau TIGERweb, public domain. These clarify names in geoBoundaries geometry; they do not replace its source boundaries.

Boundary editions vary. Source metadata dates describe the represented geometry, not the date this app imported it. These are educational source-edition maps, not a statement about sovereignty or a guarantee of current administrative boundaries. Known historical coverage is described in the source research notes and the app's boundary-edition label.
