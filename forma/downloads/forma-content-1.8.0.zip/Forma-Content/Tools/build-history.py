"""Compile reviewed history decks into the shared quiz catalogue. No network required."""
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
content = root / 'Content'
catalog = json.loads((content / 'catalog.json').read_text())
catalog = [b for b in catalog if b['domain'] != 'history']
colours = ['90B5D9', '9BC9BD', 'C1ADD6', 'E2BE91', '9ABBD0', 'D5A6B1']
order = ['antiquity','medieval','encounters','rights','twentieth','discovery','britain-ireland']
for slug in order:
    deck = json.loads((content / 'History' / f'history-{slug}.json').read_text())
    events = deck['events']
    assert len({e['id'] for e in events}) == len(events)
    assert all(e['year'] != 0 and e['tolerance'] > 0 and deck['startYear'] <= e['year'] <= deck['endYear'] for e in events)
    info = dict(id=deck['id'], title=deck['title'], domain='history', type='timeline', description=deck['subtitle'], label='Event', unit='events', flags=False, count=len(events), relatedCountries=deck['countryCodes'], keywords=' '.join(e['title'] for e in events))
    items = [dict(id=e['id'], name=e['title'], aliases=[], fact=e['summary'], flag='', path='', x=e['year'], y=0, fill=colours[i % len(colours)], symbol='', number=None, marker=False, badge=False) for i,e in enumerate(events)]
    board = dict(info=info, items=items, background='', graticule='', decor=[], timeline=deck, source='Original event summaries. Individual museum, archive, university and institutional sources are linked with each event.', sourceURL=events[0]['sourceURL'])
    (content / 'Boards' / f"{deck['id']}.json").write_text(json.dumps(board, ensure_ascii=False, indent=2)+'\n')
    catalog.append(info)
(content / 'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n')
print(f'{len(catalog)} quizzes, {len(order)} history decks')
