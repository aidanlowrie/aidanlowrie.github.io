from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]/'Content'
facts={
'Primary motor cortex':'Initiates many voluntary movements; each hemisphere mainly controls the opposite side of the body.',
'Primary somatosensory cortex':'Receives information about touch, pressure, pain, temperature and body position.',
'Medulla oblongata':'Contains centres involved in breathing, heart rate and blood pressure regulation.',
'Tongue':'Moves food during chewing and swallowing and carries taste receptors.',
'Parotid gland':'A major salivary gland; its watery secretion contains salivary amylase.',
'Duodenum':'The first small-intestinal segment receives acidic chyme, bile and pancreatic secretions.',
'Transverse colon':'The section of large intestine that crosses the abdomen from right to left.',
'Jejunum':'The middle small-intestinal segment absorbs much of the digested nutrients.',
'Ileum':'The final small-intestinal segment absorbs bile salts and vitamin B12 before joining the large intestine.',
'Ascending colon':'Carries intestinal contents upwards on the person’s right side.',
'Descending colon':'Carries intestinal contents downwards on the person’s left side.',
'Appendix':'A narrow pouch attached to the caecum that contains lymphoid tissue.',
'Nucleolus':'Produces ribosomal RNA and assembles ribosomal subunits inside the nucleus.',
'Axon terminal':'The end of an axon releases neurotransmitter onto a target cell at a chemical synapse.',
'Synaptic vesicles':'Small membrane-bound sacs store neurotransmitter for release from the presynaptic terminal.',
'Synaptic cleft':'The narrow extracellular gap across which neurotransmitter diffuses.',
'Mitochondrion':'Produces much of a respiring cell’s ATP by oxidative phosphorylation.',
'Superior vena cava':'Returns blood from the head, neck, upper limbs and thorax to the right atrium.',
'Inferior vena cava':'Returns blood from the lower body to the right atrium.',
'Pulmonary vein':'Returns oxygenated blood from the lungs to the left atrium.',
'Aortic valve':'A semilunar valve that prevents blood flowing back from the aorta into the left ventricle.',
'Pulmonary valve':'A semilunar valve that prevents blood flowing back from the pulmonary trunk into the right ventricle.',
'Plasma membrane':'A selectively permeable lipid bilayer that separates the cell from its surroundings.',
'Tonoplast':'The membrane around the plant vacuole regulates movement of solutes between vacuole and cytoplasm.',
'Rough endoplasmic reticulum':'Ribosomes on its surface make proteins destined for secretion, membranes or the endomembrane system.',
'Smooth endoplasmic reticulum':'A ribosome-free membrane network involved in lipid synthesis and, in some cells, detoxification or calcium storage.',
'Plasmodesmata':'Membrane-lined channels through plant cell walls connect neighbouring cells.',
'Flagellum':'A long cellular projection that can propel a cell; it is present in some specialised animal cells, such as sperm.',
'Electron cloud':'A probability distribution for electron position. It is not an orbital track; the nucleus inset uses a different scale.'}
changed=0
for p in (root/'Boards').glob('*.json'):
 d=json.loads(p.read_text())
 if d['info']['domain']=='geography':continue
 for item in d['items']:
  if not item['fact'] and item['name'] in facts:item['fact']=facts[item['name']];changed+=1
  if d['info']['type']=='periodic':item['fact']=item['fact'].split(' Relative atomic mass:')[0]
 p.write_text(json.dumps(d,indent=2)+'\n')
print('Filled',changed,'missing scientific descriptions')
