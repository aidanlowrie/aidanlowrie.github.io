"""Expose the UK's four constituent countries without replacing the UK entry."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]/'Content'
places=json.loads((root/'places.json').read_text())
nations=[('GB-ENG','England',['ENG'], 'gbeng'),('GB-SCT','Scotland',['SCT','Alba'], 'gbsct'),('GB-WLS','Wales',['WLS','Cymru'], 'gbwls'),('GB-NIR','Northern Ireland',['NI','N.I.','NIR'], None)]
for code,name,aliases,flag in nations:
    places=[p for p in places if p['code']!=code]
    places.append(dict(id=code,code=code,name=name,continent='Europe',aliases=aliases+['United Kingdom','UK',code],note=None,parentCode='GB',flagOverride=('🏴'+''.join(chr(0xe0000+ord(c)) for c in flag)+chr(0xe007f)) if flag else ''))
uk=next(p for p in places if p['code']=='GB')
uk['aliases']=list(dict.fromkeys(uk['aliases']+['UK','U.K.']))
(root/'places.json').write_text(json.dumps(sorted(places,key=lambda p:p['name']),ensure_ascii=False,indent=2)+'\n')
catalog=json.loads((root/'catalog.json').read_text())
for info in catalog:
    if info.get('countryCode')!='GB':continue
    nation=next(((code,name,aliases) for code,name,aliases,_ in nations if info['title'].startswith(name+' ·')),None)
    if nation:
        code,name,aliases=nation
        info['constituentCountry']=code
        info['keywords']=' '.join(dict.fromkeys((info.get('keywords','')+' '+name+' '+' '.join(aliases)+' UK United Kingdom').split()))
    elif info['id']=='regions-gbr':
        info['keywords']=' '.join(dict.fromkeys((info.get('keywords','')+' UK United Kingdom England Scotland Wales Northern Ireland NI').split()))
    path=root/'Boards'/f"{info['id']}.json";board=json.loads(path.read_text());board['info']=info
    if info['id']=='regions-gbr':
        for item in board['items']:
            if item['name']=='Northern Ireland':item['aliases']=list(dict.fromkeys(item['aliases']+['NI','N.I.']))
    path.write_text(json.dumps(board,ensure_ascii=False,separators=(',',':'))+'\n')
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
print('203 place choices; UK and its four constituent countries included.')
