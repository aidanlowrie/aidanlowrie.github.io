"""Original vector teaching schematics. Geometry shared by drawing and hit testing.
Scientific references and limitations: ../SCIENCE-REVISION-1.4.md.
"""
from pathlib import Path
import json, math, html
root=Path(__file__).resolve().parents[1]/'Content';art=root/'Artwork'
col=['#DC927F','#E5AD71','#BC9BC5','#89ADA5','#86A9CE','#CC91A5','#8B9CC6','#CEB277','#94BBA4','#B599B9','#B9A8D0','#91B9CD']
def ellipse(x,y,rx,ry):
 k=.55228475
 return f'M{x-rx} {y}C{x-rx} {y-ry*k} {x-rx*k} {y-ry} {x} {y-ry}C{x+rx*k} {y-ry} {x+rx} {y-ry*k} {x+rx} {y}C{x+rx} {y+ry*k} {x+rx*k} {y+ry} {x} {y+ry}C{x-rx*k} {y+ry} {x-rx} {y+ry*k} {x-rx} {y}Z'
class Plate:
 def __init__(self,id,title,domain,url,description):
  self.id=id;self.title=title;self.domain=domain;self.url=url;self.description=description;self.items=[];self.svg=[]
 def raw(self,s):self.svg.append(s)
 def part(self,name,path,x,y,fact,aliases=[],width=None,detail='',region=True,color=None):
  n=len(self.items);color=color or {'Glomerulus':'#C97782','Afferent arteriole':'#D5888C','Efferent arteriole':'#C77983','Peritubular capillaries':'#DAB0B8','Alveolar air space':'#EDF3F7','Type I alveolar cell':'#DBA0AF','Basement membrane':'#AE97C2','Surfactant layer':'#CAB985'}.get(name,col[n%len(col)]);id=f'{self.id}-{n+1}'
  self.items.append(dict(id=id,name=name,aliases=aliases,fact=fact,flag='',path=path,x=x,y=y,fill=color,symbol='',region=region,**({'strokeWidth':width} if width else {})))
  if width and width>=16:detail=f'<path d="{path}" fill="none" stroke="#FFFFFF" stroke-opacity="0.45" stroke-width="{width*.28}" stroke-linecap="round" stroke-linejoin="round"/>'+detail
  self.svg.append(f'<g id="{id}"><path d="{path}" fill="{"none" if width else color}" stroke="{color if width else "#657489"}" stroke-width="{width or 1.4}" stroke-linecap="round" stroke-linejoin="round" {"data-tube=\"true\"" if width else ""}/>{detail}</g>')
 def save(self,viewport=[25,25,850,590]):
  info=dict(id=self.id,title=self.title,domain=self.domain,type='diagram',description=self.description,label='Structure',unit='structures',flags=False,count=len(self.items))
  data=dict(info=info,items=self.items,background='',graticule='',decor=[],artwork=self.id+'.svg',source='Original Forma schematic; scientific reference: OpenStax. Not to scale.',sourceURL=self.url,viewport=viewport)
  (root/'Boards'/f'{self.id}.json').write_text(json.dumps(data,indent=2)+'\n')
  (art/f'{self.id}.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="900" height="640" viewBox="0 0 900 640"><metadata>Original Forma educational schematic, 2026. Scientific reference: '+html.escape(self.url)+'</metadata>'+''.join(self.svg)+'</svg>')
  return info
p=Plate('nephron','Nephron','biology','https://openstax.org/books/anatomy-and-physiology/pages/25-4-microscopic-anatomy-of-the-kidney','Renal corpuscle, tubular segments and blood supply.')
p.raw('<path d="M30 290H870" fill="none" stroke="#C4CBD6" stroke-dasharray="4 7"/><text x="35" y="274" font-family="sans-serif" font-size="12" fill="#8390A4">CORTEX</text><text x="35" y="311" font-family="sans-serif" font-size="12" fill="#8390A4">MEDULLA</text>')
p.part('Peritubular capillaries','M105 220C140 275 255 300 300 260C330 240 300 110 360 95C405 80 495 90 540 110M300 260C365 255 400 270 470 270C530 275 590 260 635 225',365,96,'A capillary network exchanges water and solutes with the cortical tubules.',width=9)
p.part('Afferent arteriole','M45 140C90 140 110 149 134 155',80,142,'Carries blood into the glomerular capillaries.',width=22)
p.part('Efferent arteriole','M139 185C111 190 95 205 105 220',109,202,'Carries blood out of the glomerulus into downstream capillaries.',width=16)
p.part('Glomerular capsule',ellipse(187,173, 70,70),190,240,'The double-walled capsule receives filtrate from the glomerulus.',["Bowman's capsule","Bowman capsule"],width=15)
p.part('Glomerulus','M141 155C150 117 210 112 228 152C245 182 220 216 185 219C150 216 142 183 161 154C178 125 215 145 208 179C199 211 165 199 170 172C175 150 199 161 192 182M143 185C125 165 165 128 194 138C220 145 236 177 209 205',189,171,'A tuft of capillaries that filters fluid from the blood.',["glomerular capillaries"],width=10)
p.part('Proximal convoluted tubule','M257 173C289 173 276 105 315 120C352 135 297 183 337 196C383 211 366 132 404 140C455 151 391 212 415 255L415 292',350,188,'Reabsorbs most filtered water and solutes; also secretes substances into the filtrate.',["proximal tubule","PCT"],width=28)
p.part('Descending limb','M415 292L415 478C415 521 435 544 455 544',415,410,'The thin descending limb is permeable to water, which leaves the tubule into the medulla.',["descending loop of Henle","descending limb of Henle"],width=19)
p.part('Ascending limb','M455 544C484 544 501 521 501 478L501 292',501,413,'Reabsorbs salt and is relatively impermeable to water.',["ascending loop of Henle","ascending limb of Henle"],width=24)
p.part('Distal convoluted tubule','M501 292L501 233C501 196 536 210 543 180C548 154 510 139 543 122C577 104 584 161 604 177C633 198 668 151 676 189C680 213 703 227 734 228',603,177,'Fine-tunes ion balance before tubular fluid enters the collecting system.',["distal tubule","DCT"],width=26)
p.part('Collecting duct','M748 104L748 562M734 228L748 242',748,396,'Receives fluid from several nephrons; hormone-regulated water reabsorption helps determine urine concentration.',width=33)
p.raw('<path d="M408 363L415 374L422 363M494 385L501 374L508 385M741 480L748 491L755 480" fill="none" stroke="#657489" stroke-width="1.2"/>')
infos=[p.save()]
p=Plate('alveolus','Alveolus','biology','https://openstax.org/books/anatomy-and-physiology/pages/22-1-organs-and-structures-of-the-respiratory-system','Airways, alveolar cells and the air–blood barrier.')
p.part('Respiratory bronchiole','M135 57L135 160C135 195 165 198 174 220',135,124,'The first airway segment with alveoli in its walls; gas exchange begins here.',width=32)
p.part('Alveolar duct','M174 220C196 250 201 273 202 308',196,272,'An air passage whose walls open into alveoli.',width=26)
sac='M202 307C224 282 262 296 256 329C290 335 283 378 254 380C252 412 209 420 194 392C157 407 133 379 147 349C127 322 166 293 186 311Z'
p.part('Alveolar sac',sac,207,357,'A cluster of alveoli opening into a common space.',detail='<path d="M202 319L209 347M158 348L184 354M193 386L203 366M252 375L224 361M252 326L229 344" fill="none" stroke="#FFFFFF" stroke-width="3"/>')
p.raw('<path d="M259 318L389 182M259 388L389 470" fill="none" stroke="#ACB7C8" stroke-width="1" stroke-dasharray="3 5"/>')
p.part('Pulmonary capillary','M468 134C665 42 837 201 824 364C814 475 700 565 571 549C477 539 409 470 397 379',807,342,'Blood flows close to the alveolar wall for oxygen and carbon dioxide exchange.',["capillary","capillary network"],width=30)
p.part('Basement membrane',ellipse(609,321,188,188),426,271,'A thin extracellular support layer; the epithelial and endothelial basement membranes form part of the air–blood barrier.',width=5)
p.part('Type I alveolar cell',ellipse(609,321,180,180),474,213,'Thin squamous epithelial cells cover most of the alveolar surface and allow gas diffusion.',["type I pneumocyte","type 1 pneumocyte","type 1 alveolar cell"],width=16)
p.part('Alveolar air space',ellipse(609,321,165,165),569,300,'The air-filled interior of an alveolus exchanges gases with adjacent blood.',["air space","alveolar lumen","alveolus"],detail='<path d="M497 290C504 265 522 243 540 233M696 404C712 383 722 360 722 338" fill="none" stroke="#FFFFFF" stroke-width="2"/>')
p.part('Surfactant layer',ellipse(609,321,161,161),474,400,'A phospholipid-rich lining lowers surface tension and helps keep alveoli open.',["surfactant","pulmonary surfactant"],width=4)
p.part('Type II alveolar cell','M676 452C659 448 655 429 667 415C679 404 699 409 708 422L713 441L695 459Z',687,433,'Cuboidal cells secrete surfactant and can replace damaged alveolar epithelial cells.',["type II pneumocyte","type 2 pneumocyte","type 2 alveolar cell"],detail='<circle cx="686" cy="431" r="8" fill="#806488"/>'+''.join(f'<circle cx="{x}" cy="{y}" r="2.5" fill="#E8D9EE"/>' for x,y in [(671,427),(680,447),(701,434),(694,418)]))
p.part('Alveolar macrophage','M621 355L628 344L639 348L650 339L658 352L672 354L668 367L678 380L665 388L663 402L649 399L636 406L628 393L614 390L620 376L611 365Z',645,374,'A mobile immune cell that removes particles, debris and microbes from alveoli.',["macrophage","dust cell"],detail='<path d="M634 365C650 354 663 373 652 385C639 394 629 380 634 365Z" fill="#96709C"/>')
rbc=''.join(ellipse(x,y,12,8) for x,y in [(562,110),(693,125),(781,218),(819,348),(745,484),(572,551),(423,445)])
p.part('Red blood cell',rbc,781,218,'Haemoglobin in erythrocytes carries most oxygen in the blood.',["erythrocyte","red blood cells","RBC"],color="#C97886",detail=''.join(f'<ellipse cx="{x}" cy="{y}" rx="5" ry="3" fill="#EBC9CA"/>' for x,y in [(562,110),(693,125),(781,218),(819,348),(745,484),(572,551),(423,445)]))
infos.append(p.save())
# Twelve deliberately distinct monofunctional structures. The defining heteroatoms
# and bond multiplicities remain readable in the uncoloured plate.
p=Plate('groups','Functional groups','chemistry','https://openstax.org/books/organic-chemistry/pages/3-1-functional-groups','Recognise twelve functional groups from general molecular structures.')
structures=[('Alcohol','R—OH','A hydroxyl group bonded to a saturated carbon.','hydroxyl'),('Ketone','R—C—R','A carbonyl carbon bonded to two carbon groups.','ketone'),('Carboxylic acid','R—C—OH','A carbonyl and hydroxyl attached to the same carbon.','carboxyl'),('Amine','R—NH₂','An amine nitrogen bonded to carbon; a primary amine is shown.','amino'),('Thiol','R—SH','A sulfhydryl group bonded to carbon.','sulfhydryl'),('Ester','R—C—O—R′','A carbonyl carbon bonded to an oxygen that is bonded to another carbon group.','ester'),('Aldehyde','R—C—H','A carbonyl carbon bonded to at least one hydrogen.','aldehyde'),('Ether','R—O—R′','An oxygen linking two carbon groups.','ether'),('Amide','R—C—NH₂','A carbonyl carbon bonded directly to nitrogen; a primary amide is shown.','amide'),('Nitrile','R—C≡N','A carbon–nitrogen triple bond.','cyano'),('Alkene','R—CH=CH—R′','A carbon–carbon double bond.','alkene'),('Alkyne','R—C≡C—R′','A carbon–carbon triple bond.','alkyne')]
for i,(name,formula,fact,alias) in enumerate(structures):
 x=25+(i%4)*220;y=40+(i//4)*190
 path=f'M{x+12} {y}H{x+196}Q{x+210} {y} {x+210} {y+14}V{y+151}Q{x+210} {y+165} {x+196} {y+165}H{x+12}Q{x} {y+165} {x} {y+151}V{y+14}Q{x} {y} {x+12} {y}Z'
 center=x+105;cy=y+102
 def atom(text,dx,dy=0):
  return f'<text x="{center+dx}" y="{cy+dy}" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="22" fill="#293A51">{text}</text>'
 def bond(x1,y1,x2,y2,count=1):
  paths=[]
  for offset in ([0] if count==1 else [-3,3] if count==2 else [-5,0,5]):
   vertical=x1==x2
   paths.append(f'M{center+x1+(offset if vertical else 0)} {cy+y1+(0 if vertical else offset)}L{center+x2+(offset if vertical else 0)} {cy+y2+(0 if vertical else offset)}')
  return f'<path d="{"".join(paths)}" fill="none" stroke="#293A51" stroke-width="1.6"/>'
 if name in ['Ketone','Carboxylic acid','Ester','Aldehyde','Amide']:
  c=-15 if name=='Ester' else 0
  right={'Ketone':'R','Carboxylic acid':'OH','Aldehyde':'H','Amide':'NH₂','Ester':'O'}[name]
  detail=atom('R',c-60)+atom('C',c)+atom('O',c,-51)+atom(right,c+55)+bond(c-47,-8,c-14,-8)+bond(c+14,-8,c+36,-8)+bond(c,-25,c,-42,count=2)
  if name=='Ester':detail+=atom('R′',c+91)+bond(c+66,-8,c+77,-8)
 elif name in ['Alkene','Alkyne']:
  symbol='CH' if name=='Alkene' else 'C'
  detail=atom('R',-80)+atom(symbol,-29)+atom(symbol,29)+atom('R′',80)+bond(-67,-8,-49,-8)+bond(49,-8,65,-8)+bond(-10,-8,10,-8,count=2 if name=='Alkene' else 3)
 elif name=='Nitrile':
  detail=atom('R',-60)+atom('C',0)+atom('N',60)+bond(-47,-8,-14,-8)+bond(14,-8,44,-8,count=3)
 elif name=='Ether':
  detail=atom('R',-60)+atom('O',0)+atom('R′',60)+bond(-47,-8,-15,-8)+bond(15,-8,43,-8)
 else:
  right={'Alcohol':'OH','Amine':'NH₂','Thiol':'SH'}[name]
  detail=atom('R',-36)+atom(right,31)+bond(-22,-8,9,-8)
 p.part(name,path,x+105,y+85,fact,[alias],detail=detail)
infos.append(p.save([20,35,875,560]))
catalog=json.loads((root/'catalog.json').read_text())
for info in infos:
 catalog=[b for b in catalog if b['id']!=info['id']]
 catalog.append(info)
catalog.sort(key=lambda b:['geography','biology','chemistry'].index(b['domain']))
(root/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
print('Created',[(i['id'],i['count']) for i in infos])
