# Rebuilding geography

The editable derived data is shipped directly in `Content/Boards/`; no download is needed to build or use the app. `Content/geography-sources.json` records per-layer original download URLs, represented years, licences and SHA-256 hashes. `GEOGRAPHY-SOURCES-1.6.md` describes source-specific corrections and validation.

`build-geography.py --workspace <workspace>` was run using Python 3, numpy, shapely 2.1.2, pyproj 3.8 and pycountry 26.2.16. It expects the original project layout (`outputs/Forma-Native/Content`) and a `work` cache:

- `catalog-1.5.json`: the retained 29-board catalogue before this import.
- `geoboundaries-adm1-index.json`: metadata snapshot, deduplicated on valid ADM1 boundary IDs.
- `subdivisions/{ISO}-ADM1.geojson` and the selected ADM2/ADM3 files plus `{ISO}-{level}-metadata.json`.
- `subdivisions-extra/candidates.json`, the three official supplementary GeoJSON sources named by that manifest, and `usa-virginia-name-corrections.json`.

The small metadata and correction inputs are included in `GeographyInputs/`. Restore them into the above work paths before rerunning. Retrieve geometry from the recorded exact source URLs and compare hashes. geoBoundaries is pinned to commit 9469f09; use media.githubusercontent.com/media/wmgeolab/geoBoundaries/ rather than a Git LFS pointer returned by a raw source URL. The OS supplementary layer was converted from EPSG:27700 to EPSG:4326; the CSO layer is interpreted as EPSG:29903. See the research notes for official source retrieval and conversion details.

The generator validates shape names, coordinates, nonempty geometry and expected official county counts; dissolves same-name fragments; disambiguates Virginia names; assigns county polygons to parents; projects across the antimeridian; simplifies while preserving polygon topology; and writes attribution, audit, catalogue and directory data. The resulting app board JSON uses SVG path coordinates in a local projected canvas, not geographic longitude/latitude.

## Continuous maps (1.7.2)

All 278 geography boards use spherical Mercator coordinates. `mapReference` maps the shared unit-Mercator world into each board; world longitude wraps at the date line. `map-world.json` is the shared, offline Natural Earth context. Only board items accept answers. Small-area circles are now separate screen-sized rendering and hit-test overlays; they are not baked into geographic outlines.

Run `build-geography.py` as above, then `add-uk-countries.py`. Base maps and context can be rebuilt independently: from this Tools directory, install Node dependency `svgpath` (`npm install --no-save svgpath`) and run `node build-map-context.mjs`. Pinned input features are in `GeographyInputs/base-maps.json`; bundled D3 retains its upstream copyright header (ISC). Natural Earth is public domain. The base features retain the original app's board membership and source attribution.
