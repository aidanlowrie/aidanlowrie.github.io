"""Rebuild local, offline subdivision boards from pinned, attributed source data.
Usage: asset-env/bin/python build-geography.py --workspace /path/to/workspace
Input cache and its provenance are listed in Content/geography-sources.json.
"""
import argparse,json,math,re,hashlib,collections
from pathlib import Path
import numpy as np
import pycountry
from shapely.geometry import shape,Polygon,MultiPolygon
from shapely.ops import transform,unary_union
from shapely import make_valid
from shapely.strtree import STRtree
from pyproj import Transformer
ap=argparse.ArgumentParser();ap.add_argument('--workspace',type=Path,default=Path.cwd());args=ap.parse_args()
root=args.workspace;content=root/'outputs/Forma-Native/Content';work=root/'work';cache=work/'subdivisions';extra=work/'subdivisions-extra'
previous=json.loads((content/'catalog.json').read_text());baseIDs={b['id'] for b in json.loads((work/'catalog-1.5.json').read_text())};base=[b for b in previous if b['id'] in baseIDs or b['domain']!='geography'];catalog=list(base);sources=[];audit=[]
metadata=[m for m in json.loads((work/'geoboundaries-adm1-index.json').read_text()) if '-ADM1-' in m['boundaryID']]
meta={m['boundaryISO']:m for m in metadata}
NAME={'GBR':'United Kingdom','USA':'United States','KOR':'South Korea','PRK':'North Korea','RUS':'Russia','IRN':'Iran','VNM':'Vietnam','LAO':'Laos','SYR':'Syria','TZA':'Tanzania','BOL':'Bolivia','VEN':'Venezuela','MDA':'Moldova','BRN':'Brunei','CZE':'Czechia','COD':'DR Congo','COG':'Republic of the Congo','PSE':'Palestine','XKX':'Kosovo','CIV':"Côte d’Ivoire",'TLS':'Timor-Leste','MKD':'North Macedonia','SWZ':'Eswatini'}
LABEL={'USA':'States and territories','CAN':'Provinces and territories','GBR':'Constituent countries','AUS':'States and territories','DEU':'States','AUT':'States','BRA':'States and federal district','MEX':'States and Mexico City','IND':'States and union territories','CHN':'Province-level divisions','JPN':'Prefectures','CHE':'Cantons','FRA':'Metropolitan regions','IRL':'Provinces','KEN':'Counties','NPL':'Provinces','SVN':'Cohesion regions','ITA':'Macroregions','GRC':'Decentralised administrations','SGP':'Planning regions','ESP':'Autonomous communities and cities','VNM':'Provinces and municipalities','IDN':'Provinces','NZL':'Regions','NOR':'Counties','SWE':'Counties'}
places=[]
for iso,m in meta.items():
 country=pycountry.countries.get(alpha_3=iso);code=country.alpha_2 if country else 'XK' if iso=='XKX' else iso[:2]
 name=NAME.get(iso,m['boundaryName']);aliases=[m['boundaryName'],iso,code]
 if country:aliases += [country.name,getattr(country,'official_name','')]
 note='This provinces quiz uses the 2017 boundary edition (34 provinces), before the later Papua subdivisions.' if iso=='IDN' else 'The regions quiz covers metropolitan France. The departments quiz also uses metropolitan boundaries.' if iso=='FRA' else None
 places.append(dict(id=iso,code=code,name=name,continent=m['Continent'],aliases=sorted(set(aliases)),note=note))
places.append(dict(id='VAT',code='VA',name='Vatican City',continent='Europe',aliases=['Holy See','Vatican','VAT','VA'],note='Vatican City has no comparable state or county subdivision quiz in the available sources. It is included in World countries.'))
placeby={p['id']:p for p in places}
for id,iso in {'us':'USA','can':'CAN','deu':'DEU','fra':'FRA','chn':'CHN'}.items():
 p=placeby[iso];info=next(x for x in catalog if x['id']==id);info.update(countryCode=p['code'],countryName=p['name'],continent=p['continent'],subdivisionLabel={'us':'50 states','can':'Provinces and territories','deu':'States','fra':'Metropolitan departments','chn':'Mainland province-level divisions'}[id],keywords=' '.join(p['aliases']))
 path=content/'Boards'/(id+'.json');d=json.loads(path.read_text());d['info']=info;path.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
def polys(g):
 if isinstance(g,Polygon):return [g]
 return [p for x in getattr(g,'geoms',[]) for p in polys(x)]
def valid(g):
 return unary_union(polys(make_valid(g)))
def read(path,namekey='shapeName',idkey='shapeID'):
 d=json.loads(path.read_text());rows=[]
 crs=d.get('crs',{}).get('properties',{}).get('name','EPSG:29903' if path.name=='irl-cso-counties26-en.geojson' else 'EPSG:4326')
 reproj=None if ('CRS84' in crs or crs in ['EPSG:4326','urn:ogc:def:crs:EPSG::4326']) else Transformer.from_crs(crs,'EPSG:4326',always_xy=True)
 for i,f in enumerate(d['features']):
  p=f['properties'];name=str(p.get(namekey) or '').strip();assert name,(path,i)
  g=shape(f['geometry'])
  if reproj:g=transform(reproj.transform,g)
  g=valid(g);assert not g.is_empty,(path,name)
  assert -180.1<=g.bounds[0]<=180.1 and -90.1<=g.bounds[1]<=90.1,(path,'unexpected CRS',g.bounds)
  rows.append(dict(name=name,id=str(p.get(idkey) or hashlib.sha256(name.encode()).hexdigest()[:12]),geometry=g,properties=p))
 return rows
def source(m,path):
 return dict(provider='geoBoundaries gbOpen',source=m['boundarySource'],url=m['boundarySourceURL'],download=m['simplifiedGeometryGeoJSON'],license=m['boundaryLicense'],licenseSource=m['licenseSource'],edition=m['boundaryYearRepresented'],boundaryID=m['boundaryID'],sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def custom(key,path):
 m=next(x for x in json.loads((extra/'candidates.json').read_text()) if x['id']==key)
 return dict(provider=m['sourceName'],source=m['sourceName'],url=m.get('sourcePage',m['source']),download=m['source'],license=m['license'],licenseSource=m.get('licenseURL',m['source']),edition=m.get('year','2026-05'),boundaryID=key,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def slug(s):return re.sub('[^a-z0-9]+','-',s.lower()).strip('-')
def board(iso,rows,id,label,src,title=None,parent=None,level=1):
 # Dissolve source fragments sharing a name (e.g. Iran's Mazandaran).
 # US city/county name collisions are resolved from Census records before this step.
 grouped=collections.defaultdict(list)
 for r in rows:grouped[r['name']].append(r)
 rows=[dict(name=n,id=rs[0]['id'],geometry=unary_union([r['geometry'] for r in rs]),properties=rs[0]['properties']) for n,rs in grouped.items()]
 if len(rows)<2:return
 p=placeby[iso];rows.sort(key=lambda r:r['name'].casefold())
 # Find a continuous longitude interval, preserving Pacific archipelagos across 180°.
 longs=np.array([xy[0] % 360 for r in rows for poly in polys(r['geometry']) for xy in poly.exterior.coords]);ls=np.sort(longs);gaps=np.diff(np.r_[ls,ls[0]+360]);start=ls[(int(np.argmax(gaps))+1)%len(ls)]
 end=start+360-float(np.max(gaps));lon0=((start+end)/2+180)%360-180
 def unwrap(x,y,z=None):return ((np.asarray(x)-lon0+180)%360-180+lon0,np.asarray(y))
 unwrapped=[transform(unwrap,r['geometry']) for r in rows];bounds=unary_union(unwrapped).bounds;lat0=max(-75,min(75,(bounds[1]+bounds[3])/2))
 # Shared spherical Mercator coordinates match the continuous world context.
 def mercator(x,y,z=None):
  lat=np.clip(np.asarray(y),-85.05112878,85.05112878)
  return (np.asarray(x)/360, np.log(np.tan(math.pi/4+np.radians(lat)/2))/(2*math.pi))
 gs=[valid(transform(mercator,g)) for g in unwrapped];bounds=unary_union(gs).bounds
 assert all(math.isfinite(x) for x in bounds),(iso,'nonfinite projection')
 xmin,ymin,xmax,ymax=bounds;scale=min(850/max(xmax-xmin,1e-9),550/max(ymax-ymin,1e-9))
 ox=(900-(xmax-xmin)*scale)/2;oy=(640-(ymax-ymin)*scale)/2
 def fit(x,y,z=None):return (ox+(np.asarray(x)-xmin)*scale,640-oy-(np.asarray(y)-ymin)*scale)
 items=[];drawn=[]
 for i,(r,g) in enumerate(zip(rows,gs)):
  original=transform(fit,g);g=original.simplify(.12,preserve_topology=True)
  assert not g.is_empty,(iso,r['name'])
  chunks=[]
  for poly in polys(g):
   for ring in [poly.exterior,*poly.interiors]:
    pts=list(ring.coords);chunks.append('M'+'L'.join(f'{x:.2f},{y:.2f}' for x,y in pts)+'Z')
  pt=original.representative_point();small=original.area<24
  path=''.join(chunks)
  aliases=[]
  for key in ['shapeISO','adm1_name1','adm1_name2','name_en']:
   val=r['properties'].get(key)
   if val and val!=r['name']:aliases.append(str(val))
  item=dict(id=id+'-'+hashlib.sha256(r['id'].encode()).hexdigest()[:12],name=r['name'],aliases=aliases,fact='',flag='',path=path,x=round(pt.x,2),y=round(pt.y,2),fill='#90B5D9',symbol='',number=None,marker=small,badge=False)
  items.append(item);drawn.append(g)
 info=dict(id=id,title=title or p['name']+' · '+label,domain='geography',type='regions',description='',label=label,unit='places',flags=False,count=len(items),countryCode=p['code'],countryName=p['name'],continent=p['continent'],subdivisionLevel=level,subdivisionLabel=label,edition=src['edition'],keywords=' '.join(p['aliases']+[r['name'] for r in rows]),parentBoardID=parent)
 attr=f"{src['provider']}. {src['source']}. Boundary edition: {src['edition']}. Licence: {src['license']}. Source: {src['url']}. Geometry reprojected and simplified for Forma; tiny areas have map markers. Boundaries follow the named source edition."
 if id=='counties-usa-virginia':attr+=' County and independent-city names: US Census Bureau TIGERweb, public domain.'
 if 'Ordnance Survey' in attr:attr+=' Contains OS data © Crown copyright and database right 2026.'
 data=dict(info=info,items=items,background='',graticule='',decor=[],source=attr,sourceURL=src['url'] if src['url'].startswith('http') else 'https://www.geoboundaries.org/',viewport=[round(ox-10,2),round(oy-10,2),round(900-2*ox+20,2),round(640-2*oy+20,2)],mapReference=dict(scale=scale,x=ox-xmin*scale,y=640-oy+ymin*scale))
 (content/'Boards'/(id+'.json')).write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
 catalog.append(info);sources.append(dict(boardID=id,**src));audit.append(dict(id=id,count=len(items),tinyRegions=sum(x['marker'] for x in items),vertices=sum(len(p.exterior.coords) for g in drawn for p in polys(g))))
 return id
for iso,m in meta.items():
 path=cache/(iso+'-ADM1.geojson');rows=read(path);src=source(m,path);label=LABEL.get(iso, m['boundaryCanonical'] if m['boundaryCanonical'] not in ['Unknown','Unknown.','nan',''] and len(m['boundaryCanonical'])<50 else 'Administrative areas')
 if iso=='MCO':
  path=cache/'MCO-ADM2.geojson';rows=read(path);src=source(json.loads((cache/'MCO-ADM2-metadata.json').read_text()),path);label='Wards'
 if iso=='VNM':
  path=extra/'vnm-adm1-2025.geojson';rows=read(path,'adm1_name','adm1_pcode');src=custom('vnm2025',path)
 if iso in ['USA','CAN','DEU']:continue # Existing stable boards keep their identifiers and saved progress.
 if iso=='IRN':label='Provinces'
 board(iso,rows,'regions-'+iso.lower(),label,src,level=2 if iso=='MCO' else 1)
 print(iso,len(rows),flush=True)
# County/local-area maps, grouped into their parent state or constituent country.
for iso in ['USA','GBR']:
 parents=read(cache/(iso+'-ADM1.geojson'));children=read(cache/(iso+'-ADM2.geojson'))
 if iso=='USA':
  corrections=json.loads((extra/'usa-virginia-name-corrections.json').read_text())
  for child in children:
   if child['id'] in corrections:
    child['properties']['name_en']=child['name'];child['name']=corrections[child['id']]['name']
 gs=[p['geometry'] for p in parents];tree=STRtree(gs);groups=collections.defaultdict(list);fallback=[]
 for child in children:
  point=child['geometry'].representative_point();hits=tree.query(point,predicate='intersects')
  if len(hits):index=int(hits[0])
  else:
   candidates=tree.query(child['geometry']);areas=[(gs[int(i)].intersection(child['geometry']).area,int(i)) for i in candidates]
   if areas and max(areas)[0]>0:index=max(areas)[1]
   else:
    index=int(tree.nearest(point));distance=gs[index].distance(point);assert distance<.3,(iso,child['name'],distance);fallback.append(child['name'])
  groups[index].append(child)
 src=source(json.loads((cache/(iso+'-ADM2-metadata.json')).read_text()),cache/(iso+'-ADM2.geojson'))
 for index,rows in groups.items():
  name=parents[index]['name'];label='Counties & equivalents' if iso=='USA' else 'Local authority areas'
  board(iso,rows,'counties-'+iso.lower()+'-'+slug(name),label,src,title=name+' · '+('Counties' if iso=='USA' else 'Local areas'),parent='us' if iso=='USA' else 'regions-gbr',level=2)
 print(iso,'counties assigned',len(children),'nearest fallbacks',fallback,flush=True)
# Official familiar county geographies, distinct from administrative levels.
path=extra/'irl-cso-counties26-en.geojson';rows=[r for r in read(path,'AREA_NAME','AREA_ID') if r['id']!='00'];board('IRL',rows,'counties-ireland','26 counties',custom('ireland26',path),title='Ireland · Counties',level=2)
path=extra/'gbr-os-ceremonial-2026.geojson';rows=read(path,'NAME','NAME');src=custom('osceremonial',path)
countries=read(cache/'GBR-ADM1.geojson')
ceremonial=collections.defaultdict(list)
for row in rows:
 point=row['geometry'].representative_point()
 parent=max(countries,key=lambda p:p['geometry'].intersection(row['geometry']).area)
 ceremonial[parent['name']].append(row)
for part,label,expected in [('England','Ceremonial counties',48),('Wales','Preserved counties',8),('Scotland','Lieutenancy areas',35)]:
 selected=ceremonial[part];assert len(selected)==expected,(part,len(selected))
 board('GBR',selected,'counties-'+part.lower(),label,src,title=part+' · '+label,parent='regions-gbr',level=2)
# Familiar subdivisions that occur below ADM1 in these source hierarchies.
for iso,level,label in [('ITA','ADM2','Regions'),('SVN','ADM2','Municipalities'),('UGA','ADM3','Districts'),('GRC','ADM2','Regions and Mount Athos')]:
 path=cache/(iso+'-'+level+'.geojson');m=json.loads((cache/(iso+'-'+level+'-metadata.json')).read_text())
 board(iso,read(path),'areas-'+iso.lower(),label,source(m,path),parent='regions-'+iso.lower(),level=int(level[-1]))
# No fabricated subdivision quiz for Vatican City; directory still includes it.
places.sort(key=lambda p:p['name'].casefold())
(content/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':')))
(content/'places.json').write_text(json.dumps(places,ensure_ascii=False,separators=(',',':')))
(content/'geography-sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
(content/'geography-audit.json').write_text(json.dumps(dict(boards=len(catalog),places=len(places),newBoards=len(audit),items=sum(x['count'] for x in audit),details=audit),indent=2))
print('TOTAL',len(catalog),'boards',len(places),'places',sum(x['count'] for x in audit),'new targets')
