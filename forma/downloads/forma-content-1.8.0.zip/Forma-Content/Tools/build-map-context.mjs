// Run from this Tools directory after npm install --no-save svgpath.
import fs from 'node:fs';
import vm from 'node:vm';
import svgpath from 'svgpath';
const root='../Content';
const inputs=JSON.parse(fs.readFileSync('GeographyInputs/base-maps.json'));
const context=vm.createContext({world:inputs.world});
vm.runInContext(fs.readFileSync('GeographyInputs/d3.min.js','utf8'),context);
const d3=context.d3;
const norm=(d,precision=5)=>d?svgpath(d).unarc().unshort().abs().round(precision).toString():'';
const mercY=lat=>Math.log(Math.tan(Math.PI/4+Math.max(-85.05112878,Math.min(85.05112878,lat))*Math.PI/360));
// Store the surrounding world once, in unit Mercator coordinates.
const globalProjection=d3.geoMercator().scale(1/(2*Math.PI)).translate([0,0]);
const globalPath=d3.geoPath(globalProjection).digits(10);
fs.writeFileSync(`${root}/map-world.json`,JSON.stringify(context.world.features.map(f=>({name:f.properties.NAME_EN,path:norm(globalPath(f),9)}))));
const audit=[];
for(const entry of inputs.boards){
 const b=entry.board;
 const file=`${root}/Boards/${b.id}.json`,data=JSON.parse(fs.readFileSync(file));
 const raw=entry.items;let p=d3.geoMercator(),rotation=0;
 const collection={type:'FeatureCollection',features:raw.map(r=>r.feature||{type:'Feature',properties:{},geometry:{type:'Point',coordinates:r.coord}})};
 if(b.center){
  rotation=b.id==='oceania'?155:0;
  p.rotate([-rotation,0]).center(b.id==='oceania'?[0,-15]:b.center).scale(b.scale).translate([450,320]);
  data.viewport=[-14,-14,928,668];
 } else {
  if(b.id==='us')rotation=-130;
  p.rotate([-rotation,0]).fitExtent([[28,28],[872,612]],collection);
  const bounds=d3.geoPath(p).bounds(collection);
  data.viewport=[bounds[0][0]-12,bounds[0][1]-12,bounds[1][0]-bounds[0][0]+24,bounds[1][1]-bounds[0][1]+24];
 }
 const path=d3.geoPath(p).digits(5),centre=p.center(),t=p.translate(),k=p.scale();
 data.mapReference={scale:k*2*Math.PI,x:t[0]-k*(rotation+centre[0])*Math.PI/180,y:t[1]+k*mercY(centre[1])};
 for(const r of raw){
  const item=data.items.find(x=>x.id===r.id);if(!item)throw Error(`${b.id}/${r.id}: changed ID`);
  const xy=r.coord?p(r.coord):path.centroid(r.feature);
  if(!xy||!xy.every(Number.isFinite))throw Error(`${b.id}/${r.id}: invalid centre`);
  item.x=xy[0];item.y=xy[1];
  // Points retain a real circle for thumbnails; map markers are a separate overlay.
  item.path=b.type==='points'?`M${xy[0]-2},${xy[1]}L${xy[0]},${xy[1]-2}L${xy[0]+2},${xy[1]}L${xy[0]},${xy[1]+2}Z`:norm(path(r.feature));
  item.marker=b.type==='points'||path.area(r.feature)<80;
  if(!item.path)throw Error(`${b.id}/${r.id}: missing geometry`);
 }
 data.background='';data.graticule='';
 data.mapContextSource='Natural Earth, public domain. Continuous Mercator context; quiz membership follows the existing board.';
 fs.writeFileSync(file,JSON.stringify(data));audit.push({id:b.id,reference:data.mapReference,viewport:data.viewport,count:data.items.length});
}
fs.writeFileSync('../Content/map-base-audit.json',JSON.stringify(audit,null,2));
console.log('Reprojected '+audit.length+' base maps; shared world context generated.');
