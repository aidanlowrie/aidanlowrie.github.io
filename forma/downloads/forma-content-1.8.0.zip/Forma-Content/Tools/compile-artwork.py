"""Build native vector plates from the licensed SVG originals. Requires CairoSVG/lxml."""
from pathlib import Path
from lxml import etree as E
import cairosvg,copy
art=Path(__file__).resolve().parents[1]/'Content/Artwork'
ns='{http://www.w3.org/2000/svg}'
for source in sorted(art.glob('*.svg')):
 cairosvg.svg2pdf(url=str(source),write_to=str(source.with_suffix('.pdf')))
 root=E.fromstring(source.read_bytes())
 def walk(e,hidden=False):
  if not isinstance(e.tag,str):return
  tag=e.tag.split('}')[-1]
  if tag in ['metadata','namedview']:return
  styles={a.split(':',1)[0].strip():a.split(':',1)[1].strip() for a in e.get('style','').split(';') if ':' in a}
  if tag=='stop':
   styles['stop-color']='#FFFFFF';e.set('stop-color','#FFFFFF')
  if tag in ['path','rect','circle','ellipse','polygon','polyline','line','text']:
   fill=styles.get('fill',e.get('fill','black'))
   stroke=styles.get('stroke',e.get('stroke','none'))
   if fill!='none':styles['fill']='#FFFFFF';e.set('fill','#FFFFFF')
   if stroke!='none' or fill!='none':
    styles['stroke']='#9DAEC5';e.set('stroke','#9DAEC5')
    width=styles.get('stroke-width',e.get('stroke-width','0.65'))
    try:width=str(min(1.5,max(0.45,float(width))))
    except ValueError:width='0.65'
    styles['stroke-width']=width;e.set('stroke-width',width)
   if tag=='text':styles['fill']='#8290A5';styles['stroke']='none'
  e.set('style',';'.join(k+':'+v for k,v in styles.items()))
  for child in list(e):
   # Wide anatomical tubes need outlined walls, not a thin centreline.
   if child.get('data-tube') == 'true':
    border=copy.deepcopy(child);border.attrib.pop('data-tube',None)
    border.set('stroke','#9DAEC5');border.set('stroke-width',str(float(child.get('stroke-width'))+1.4))
    e.insert(e.index(child),border)
    child.set('stroke','#FFFFFF');child.attrib.pop('data-tube',None)
   else:walk(child)
 walk(root)
 svg=E.tostring(root)
 outline=source.with_name(source.stem+'-outline.pdf')
 cairosvg.svg2pdf(bytestring=svg,write_to=str(outline))
 print(source.stem,'colour + outline vector plates')
