# Forma 1.7 — history content and source notes

Research date: 21 September 2026. Scope: seven introductory thematic decks, eight events each. These are selected milestones, not an exhaustive survey of global history. Coverage includes East and South Asia, West and southern Africa, the Caribbean, North and South America, Oceania, the Middle East and Europe; representation is uneven. The science deck currently concentrates on European and US institutions and should be broadened in a later content expansion.

## Content contract

The files in `Content/History/` contain original English paragraphs, stable deck/event identifiers, a target year, a gameplay tolerance and a direct institutional source link for each event. Each paragraph explains the event, context and significance in 80–120 words. No paragraph includes its exact target year or a numeric date; the year is separate answer metadata. The supplied summaries are newly written syntheses, not quotations or extracts. Each primary source page supports one event (under 120 words), within the 200-word per-page derivation limit; supplementary sources below support specific qualifications.

Negative integers mean BCE and positive integers mean CE. There is no historical year zero. Year precision is deliberately limited: the game must not imply that events sharing a year have a known order unless more precise data are introduced. This release avoids duplicate target years inside any deck. `tolerance` is a pedagogical acceptance radius in years, not an estimate of uncertainty in the historical evidence. The one explicitly approximate target is Hammurabi's inscription, conventionally placed around 1750 BCE by the Louvre. All other targets identify a specific accession, publication, proclamation, institutional opening or other milestone rather than an arbitrary point within a prolonged process.

Country codes provide present-day geographical associations for optional discovery suggestions. They are not claims that today's borders or national identities existed when an event occurred, nor an assertion of territorial sovereignty. Events and text must remain readable offline; opening a citation is optional.

## Editorial decisions

- Hammurabi: the date is approximate, and the paragraph identifies the inscription as a collection of judgments and a statement of royal justice rather than a modern equal-rights code. [Louvre](https://www.louvre.fr/le-code-de-hammurabi).
- Cyrus: no claim that the cylinder was the world's first human-rights declaration. It is a royal account of conquest and religious restoration. [British Museum object record](https://www.britishmuseum.org/collection/object/W_1880-0617-1941).
- Han: the target is Liu Bang becoming emperor in 202 BCE. The conventional dynastic starting date, 206 BCE, is a different milestone. [Smithsonian timeline](https://asia-archive.si.edu/learn/for-educators/teaching-china-with-the-smithsonian/interactives/timelines/timeline-of-chinese-history-art-and-culture/) and [British Museum biography](https://www.britishmuseum.org/collection/term/BIOG2540).
- Gaugamela: conquest did not cease instantly after the battle. The museum's contemporary astronomical diary is supplementary evidence alongside its exhibition guide. [British Museum tablet](https://www.britishmuseum.org/collection/object/W_1880-0617-496).
- Mansa Musa: use the pilgrimage's departure year, without repeating unreliable wealth rankings or precise entourage totals. [Smithsonian exhibition guide](https://africa.si.edu/wp-content/uploads/Caravans_TeachersGuide.pdf).
- Voyages and conquest: Columbus does not begin American history; da Gama and Zheng He enter existing trading networks. Tenochtitlan's fall includes Indigenous allies, disease and Indigenous continuity. [Library of Congress, Columbus and the Taíno](https://wwws.loc.gov/exhibits/exploring-the-early-americas/columbus-and-the-taino.html), [Singapore National Library's maritime exhibition](https://exhibitions.nlb.gov.sg/files/mappingtheworld/nlb%20mapping%20the%20world_exhibition%20guide_en_web.pdf), [Library of Congress, Encounters in America](https://wwws.loc.gov/rr/hispanic/guide/encameri.html).
- Qing: 1644 is the move to Beijing, not the earlier naming of the dynasty or the final defeat of all resistance. [Palace Museum](https://www.dpm.org.cn/court/event/159873.html).
- Brazil: the proclamation is distinguished from a prolonged, regionally varied independence struggle. [Brazilian Ministry of Science museum](https://www.gov.br/mast/pt-br/assuntos/noticias/2022/julho/as-independencias-do-brasil/).
- Suffrage: New Zealand's parliamentary franchise included Māori women, but voting and standing for Parliament were separate reforms. [Manatū Taonga milestones](https://nzhistory.govt.nz/politics/womens-suffrage/suffrage-milestones).
- The Universal Declaration is not described as an immediately enforceable treaty. [UN treaty terminology](https://treaties.un.org/Pages/overview.aspx?path=overview%2Fdefinition%2Fpage1_en.xml).
- The invasion of Poland is identified as the conventional European start of the Second World War; earlier war in Asia is acknowledged. [United States Holocaust Memorial Museum](https://encyclopedia.ushmm.org/content/en/article/invasion-of-poland-fall-1939).
- Ghana: avoids the misleading unqualified claim that it was the first independent sub-Saharan state. The UN record establishes independence and the former Togoland territory's incorporation; the Ghanaian ministry provides Nkrumah's role. [UN decolonisation record](https://www.un.org/dppa/decolonization/history/former-trust-and-nsgts), [Ghana Ministry of Foreign Affairs](https://mfa.gov.gh/index.php/about-ghana/).
- Science: distinguishes publication, observation and development; credits Wallace, the later penicillin teams, and Franklin/Gosling/Wilkins. Jenner is described with a modern ethical qualification, rather than presented as a procedure to reproduce. [Natural History Museum](https://www.nhm.ac.uk/discover/charles-darwin-most-famous-biologist.html), [American Chemical Society](https://www.acs.org/education/whatischemistry/landmarks/flemingpenicillin.html), [King's College London](https://www.kcl.ac.uk/the-story-behind-photograph-51), [Jenner Institute](https://www.jenner.ac.uk/about/edward-jenner).
- Ireland: 1921 targets the Northern Ireland Parliament's opening, avoiding confusion between the 1920 Act, partition's implementation, the 1921 Treaty and the 1922 Free State. [National Archives](https://www.nationalarchives.gov.uk/education/resources/irish-partition/).
- Famine: identifies the beginning of a multi-year catastrophe and includes social vulnerability and relief policy alongside potato blight. [National Archives of Ireland research guide](https://nationalarchives.ie/help-with-research/research-guides/famine-records-distress-papers-and-the-relief-commission/) and [archival account of relief limitations](https://www.nationalarchives.ie/wp-content/uploads/2019/03/Great_Famine_TomQuinlan.pdf).
- Belfast Agreement: a political framework and democratic institutions, not an assertion that all subsequent violence or conflict disappeared. [Agreement text](https://www.gov.uk/government/publications/the-belfast-agreement) and [Northern Ireland Assembly explanation](https://education.niassembly.gov.uk/post-16/snapshots-devolution/belfast-agreementgood-friday-agreement-1998).

## Source register

Each row records the answer milestone and the source shipped with the event. Dates and key event descriptions were checked through institutional search results and accessible pages. Some sites blocked direct automated retrieval with HTTP 403, despite exposing their indexed institutional text (notably some British Museum/National Archives pages and the Jenner Institute); their links remain direct institutional references. This is source verification and editorial synthesis, not an independent specialist peer review. No images or proprietary museum text are bundled.

### The ancient world

File: `Content/History/history-antiquity.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| Hammurabi's laws are inscribed | 1750 BCE | ±100 years | [Musée du Louvre — Le Code de Hammurabi](https://www.louvre.fr/le-code-de-hammurabi) |
| Cyrus takes Babylon | 539 BCE | ±25 years | [British Museum — The Cyrus cylinder](https://www.britishmuseum.org/collection/object/W_1880-0617-1941) |
| Alexander wins at Gaugamela | 331 BCE | ±20 years | [British Museum — Luxury and power exhibition guide](https://www.britishmuseum.org/sites/default/files/2023-04/Luxury_and_power_large_print_guide.pdf) |
| Qin unifies the rival kingdoms | 221 BCE | ±20 years | [National Palace Museum — Oval Liang Measure by imperial decree](https://theme.npm.edu.tw/selection/Article.aspx?lang=2&sNo=04001146) |
| Liu Bang becomes Han emperor | 202 BCE | ±20 years | [Smithsonian National Museum of Asian Art — Timeline of Chinese History, Art, and Culture](https://asia-archive.si.edu/learn/for-educators/teaching-china-with-the-smithsonian/interactives/timelines/timeline-of-chinese-history-art-and-culture/) |
| The Rosetta Stone decree is issued | 196 BCE | ±20 years | [British Museum — The Rosetta Stone](https://www.britishmuseum.org/collection/object/Y_EA24) |
| Octavian wins the Battle of Actium | 31 BCE | ±20 years | [British Museum — Legion exhibition activity cards](https://www.britishmuseum.org/sites/default/files/2024-02/Legion_KS4_exhibition_activity_cards.pdf) |
| Vesuvius buries Pompeii | 79 CE | ±20 years | [Pompeii Archaeological Park — Pompeii after the Eruption](https://pompeiisites.org/en/pompeii-map/analysis/pompeii-after-the-eruption/) |

### Britain and Ireland

File: `Content/History/history-britain-ireland.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| Robert Bruce wins at Bannockburn | 1314 CE | ±10 years | [Historic Environment Scotland — Three Things About the Battle of Bannockburn](https://blog.historicenvironment.scot/2025/06/three-things-about-the-battle-of-bannockburn/) |
| England and Scotland form Great Britain | 1707 CE | ±5 years | [UK Parliament — United into One Kingdom](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/act-of-union-1707/overview/united-into-one-kingdom/) |
| The union with Ireland takes effect | 1801 CE | ±3 years | [UK Parliament — Parliamentary union](https://www.parliament.uk/about/living-heritage/evolutionofparliament/legislativescrutiny/parliamentandireland/overview/parliamentary-union/) |
| The Great Famine begins in Ireland | 1845 CE | ±3 years | [National Archives of Ireland — Famine Records and Distress Papers](https://nationalarchives.ie/help-with-research/research-guides/famine-records-distress-papers-and-the-relief-commission/) |
| The Easter Rising begins | 1916 CE | ±2 years | [National Library of Ireland — The Rising](https://www.nli.ie/1916/exhibition/en/content/rising/) |
| Northern Ireland's Parliament opens | 1921 CE | ±2 years | [The National Archives — Irish Partition](https://www.nationalarchives.gov.uk/education/resources/irish-partition/) |
| The National Health Service opens | 1948 CE | ±2 years | [The National Archives — The foundation of the NHS](https://www.nationalarchives.gov.uk/explore-the-collection/stories/the-foundation-of-the-nhs/) |
| The Belfast Agreement is reached | 1998 CE | ±2 years | [UK Government — The Belfast Agreement](https://www.gov.uk/government/publications/the-belfast-agreement) |

### Science and discovery

File: `Content/History/history-discovery.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| Copernicus publishes his solar model | 1543 CE | ±5 years | [University of Cambridge — Starry Messenger: Copernicus's Book](https://www.sites.hps.cam.ac.uk/starry/coperbooks.html) |
| Newton publishes the Principia | 1687 CE | ±5 years | [Cambridge University Library — Gravity and glory](https://wwwe.lib.cam.ac.uk/CUL/exhibitions/Footprints_of_the_Lion/gravity_glory.html) |
| Jenner tests protection using cowpox | 1796 CE | ±3 years | [University of Oxford, Jenner Institute — About Edward Jenner](https://www.jenner.ac.uk/about/edward-jenner) |
| On the Origin of Species is published | 1859 CE | ±3 years | [Natural History Museum — Charles Darwin: History's most famous biologist](https://www.nhm.ac.uk/discover/charles-darwin-most-famous-biologist.html) |
| Mendeleev presents his periodic system | 1869 CE | ±3 years | [Royal Society of Chemistry — Development of the periodic table](https://periodic-table.rsc.org/about) |
| Fleming observes penicillin's effect | 1928 CE | ±2 years | [American Chemical Society — Discovery and Development of Penicillin](https://www.acs.org/education/whatischemistry/landmarks/flemingpenicillin.html) |
| The DNA double-helix model is published | 1953 CE | ±2 years | [King's College London — The story behind Photograph 51](https://www.kcl.ac.uk/the-story-behind-photograph-51) |
| Apollo 11 lands people on the Moon | 1969 CE | ±2 years | [NASA — Apollo 11 Mission Overview](https://www.nasa.gov/history/apollo-11-mission-overview/) |

### Empires and encounters

File: `Content/History/history-encounters.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| Zheng He's first expedition departs | 1405 CE | ±10 years | [National Library Board Singapore — Mapping the World exhibition guide](https://exhibitions.nlb.gov.sg/files/mappingtheworld/nlb%20mapping%20the%20world_exhibition%20guide_en_web.pdf) |
| Columbus reaches the Caribbean | 1492 CE | ±5 years | [Library of Congress — Columbus and the Taíno](https://wwws.loc.gov/exhibits/exploring-the-early-americas/columbus-and-the-taino.html) |
| Da Gama reaches Calicut by sea | 1498 CE | ±5 years | [National Library Board Singapore — The Itinerario: The Key to the East](https://biblioasia.nlb.gov.sg/all-sections/vol-5-issue-4-jan-2010-east-itinenario-key/) |
| Tenochtitlan falls after a siege | 1521 CE | ±5 years | [Library of Congress — Florentine Codex, Book XII: The Conquest of Mexico](https://www.loc.gov/resource/gdcwdl.wdl_10623/?sp=1&st=list) |
| Babur establishes Mughal rule | 1526 CE | ±5 years | [Victoria and Albert Museum — The arts of the Mughal Empire](https://www.vam.ac.uk/articles/the-arts-of-the-mughal-empire) |
| The Tokugawa shogunate is established | 1603 CE | ±5 years | [British Museum — Samurai exhibition guide](https://www.britishmuseum.org/exhibitions/samurai/samurai-large-print-guide) |
| The Qing establish their capital in Beijing | 1644 CE | ±5 years | [The Palace Museum — The Qing court moves its capital to Beijing](https://www.dpm.org.cn/court/event/159873.html) |
| The Dutch establish a Cape supply station | 1652 CE | ±5 years | [Western Cape Government — Oude Molen socio-historical impact assessment](https://www.westerncape.gov.za/tpw/sites/tpw.westerncape.gov.za/files/atoms/files/Annexure%20C%20Socio-historical%20Impact%20Assessment%2C%20Oude%20Molen%2C%20August%202024.pdf) |

### The medieval world

File: `Content/History/history-medieval.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| The Tang dynasty is founded | 618 CE | ±15 years | [The Metropolitan Museum of Art — Tang Dynasty](https://www.metmuseum.org/it/essays/tang-dynasty-618-906) |
| Baghdad is founded as a capital | 762 CE | ±15 years | [The Metropolitan Museum of Art — The Art of the Abbasid Period](https://www.metmuseum.org/ko/essays/the-art-of-the-abbasid-period-750-1258) |
| Charlemagne is crowned emperor | 800 CE | ±10 years | [The Metropolitan Museum of Art — Medieval Sculpture, 800 to 1400](https://resources.metmuseum.org/resources/metpublications/pdf/Medieval_Sculpture_at_the_Metropolitan_800_1400_The_Metropolitan_Museum_of_Art_Bulletin_v_62_no_4_Spring_2005.pdf) |
| The Battle of Hastings | 1066 CE | ±10 years | [English Heritage — Battle Abbey and 1066 Battlefield](https://www.english-heritage.org.uk/visit/places/1066-battle-of-hastings-abbey-and-battlefield/history-and-stories/) |
| Temüjin is proclaimed Genghis Khan | 1206 CE | ±10 years | [Columbia University — The Mongols in World History: Genghis Khan](https://www-1.gsb.columbia.edu/mongols/pop/genghis/genghis_pop.htm) |
| King John seals Magna Carta | 1215 CE | ±10 years | [The National Archives — Magna Carta](https://www.nationalarchives.gov.uk/explore-the-collection/explore-by-time-period/medieval/magna-carta/) |
| Mansa Musa begins his pilgrimage | 1324 CE | ±10 years | [Smithsonian National Museum of African Art — Caravans of Gold teacher guide](https://africa.si.edu/wp-content/uploads/Caravans_TeachersGuide.pdf) |
| The Ottomans capture Constantinople | 1453 CE | ±5 years | [University of Oxford — Fall of Constantinople](https://www.cabinet.ox.ac.uk/fall-constantinople-1453) |

### Revolutions and rights

File: `Content/History/history-rights.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| The American Declaration is adopted | 1776 CE | ±3 years | [US National Archives — Declaration of Independence](https://www.archives.gov/milestone-documents/declaration-of-independence) |
| France adopts a declaration of rights | 1789 CE | ±3 years | [Élysée — The Declaration of the Rights of Man and of the Citizen](https://www.elysee.fr/en/french-presidency/the-declaration-of-the-rights-of-man-and-of-the-citizen) |
| Haiti declares independence | 1804 CE | ±3 years | [US Office of the Historian — The United States and the Haitian Revolution](https://history.state.gov/milestones/1784-1800/haitian-rev) |
| Brazil proclaims independence | 1822 CE | ±3 years | [Museu de Astronomia e Ciências Afins — As independências do Brasil](https://www.gov.br/mast/pt-br/assuntos/noticias/2022/julho/as-independencias-do-brasil/) |
| New Zealand grants women the vote | 1893 CE | ±3 years | [Manatū Taonga — New Zealand women and the vote](https://nzhistory.govt.nz/politics/womens-suffrage) |
| India and Pakistan gain independence | 1947 CE | ±2 years | [The National Archives — Partition of British India](https://www.nationalarchives.gov.uk/education/resources/partition-of-british-india/) |
| The UN adopts the Universal Declaration | 1948 CE | ±2 years | [United Nations — History of the Declaration](https://www.un.org/en/about-us/udhr/history-of-the-declaration) |
| South Africa holds its first democratic election | 1994 CE | ±2 years | [South African Government — Milestones of 20 Years of Freedom](https://www.gov.za/issues/20years/milestones-20-years-freedom) |

### The twentieth-century world

File: `Content/History/history-twentieth.json`

| Event | Target | Tolerance | Source |
|---|---:|---:|---|
| The First World War begins | 1914 CE | ±2 years | [National Army Museum — 1914: To arms](https://www.nam.ac.uk/explore/to-arms-1914) |
| The Bolsheviks seize power in Russia | 1917 CE | ±2 years | [United States Holocaust Memorial Museum — Russian Revolution](https://encyclopedia.ushmm.org/content/en/article/the-russian-revolution-1917) |
| Germany invades Poland | 1939 CE | ±2 years | [United States Holocaust Memorial Museum — Invasion of Poland](https://encyclopedia.ushmm.org/content/en/article/invasion-of-poland-fall-1939) |
| The United Nations comes into existence | 1945 CE | ±2 years | [United Nations — History of the United Nations](https://www.un.org/en/about-us/history-of-the-un) |
| The People's Republic of China is proclaimed | 1949 CE | ±2 years | [US Office of the Historian — The Chinese Revolution](https://history.state.gov/milestones/1945-1952/chinese-rev) |
| The Suez Crisis erupts | 1956 CE | ±2 years | [US Office of the Historian — The Suez Crisis](https://history.state.gov/milestones/1953-1960/suez) |
| Ghana becomes independent | 1957 CE | ±2 years | [United Nations — Former Trust and Non-Self-Governing Territories](https://www.un.org/dppa/decolonization/history/former-trust-and-nsgts) |
| The Berlin Wall's crossings open | 1989 CE | ±2 years | [State of Berlin — Opening and fall of the Berlin Wall](https://www.berlin.de/en/history/8482274-8619314-opening-and-fall-of-the-berlin-wall.en.html) |

## Validation

Validated JSON for 7 decks and 56 events. All deck IDs and event IDs are unique. Every deck has eight distinct target years; all lie within the declared range. Paragraphs contain 93–102 whitespace-separated words (total 5421). Every source uses an HTTPS URL. Every tolerance is positive. No event uses year zero and no paragraph contains its exact target year.
