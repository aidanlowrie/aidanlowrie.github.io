# Geography data in Forma 1.6

The new subdivision layers retain their original licences independently. `geography-sources.json` gives each board's provider, original contributors, represented year, download URL, licence and licence-source URL. Each board JSON also carries a readable attribution, displayed in the app's Map data panel. No endorsement is implied.

Derived geometry is included in editable JSON/SVG-path form in `Boards/`, alongside its names and identifiers. Forma's modifications are reprojection, simplification, grouping by parent region, joining same-name fragments, and small-area markers. `Tools/build-geography.py` supplies the transformation recipe. The source distribution includes these adapted datasets without access restrictions.

Layers attributed to Open Data Commons Open Database Licence 1.0 are made available, including Forma's modifications, under ODbL 1.0: https://opendatacommons.org/licenses/odbl/1-0/ . Individual contents retain any separate rights identified in their source. This notice applies to the corresponding geographic databases, not unrelated app code.

Layers attributed to Creative Commons Attribution-ShareAlike remain under their corresponding licence, including Forma's adaptations:
- CC BY-SA 2.0: https://creativecommons.org/licenses/by-sa/2.0/
- CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/

Other per-layer terms (consult the manifest for the applicable layer):
- CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
- CC BY 3.0: https://creativecommons.org/licenses/by/3.0/
- CC BY 3.0 IGO: https://creativecommons.org/licenses/by/3.0/igo/
- CC BY 2.5: https://creativecommons.org/licenses/by/2.5/
- CC BY 2.5 India: https://creativecommons.org/licenses/by/2.5/in/
- CC0: https://creativecommons.org/publicdomain/zero/1.0/
- Open Government Licence 3.0: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
- Etalab Open Licence 2.0 and swisstopo: source-specific terms linked in the manifest.

Great Britain ceremonial county data: Contains OS data © Crown copyright and database right 2026. Ordnance Survey Boundary-Line, May 2026, Open Government Licence 3.0.

Ireland county data: Central Statistics Office, Government of Ireland, CC BY 4.0. Northern Ireland context is excluded from the 26-county quiz. The original file has no declared CRS; interpreting its coordinates as Irish Grid EPSG:29903 was checked against county locations before conversion.

Vietnam 2025 provinces: General Statistics Office of Vietnam, distributed by OCHA/HDX under CC BY 3.0 IGO. Adapted from the 34-province boundary dataset.

Virginia county and independent-city labels: US Census Bureau TIGERweb, public domain. These clarify names in geoBoundaries geometry; they do not replace its source boundaries.

Boundary editions vary. Source metadata dates describe the represented geometry, not the date this app imported it. These are educational source-edition maps, not a statement about sovereignty or a guarantee of current administrative boundaries. Known historical coverage is described in the source research notes and the app's boundary-edition label.
