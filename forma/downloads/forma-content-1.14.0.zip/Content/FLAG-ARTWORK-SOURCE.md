# Flag artwork

Forma bundles the SVG country-flag artwork maintained by Hampus Joakim Borgos and contributors. The artwork was originally sourced from Wikimedia Commons and is supplied by the upstream project as public-domain flag artwork, with national proportions retained.

Upstream states: “The flags are not under copyright protection since flags are in public domain”.

Source and rights statement: https://github.com/hampusborgos/country-flags/blob/c09927e63705529bbf59ca6684cd9b23225dddad/README.md

The pinned revision and SHA-256 hash of every bundled SVG are recorded in `FLAG-ARTWORK.json`.

SVG artwork is compiled to vector PDF with CairoSVG 2.9.1 for reliable native rendering of references, clipping and percentage dimensions. Before conversion, an explicit root width and height bounded to 256 points prevents oversized compiled image caches. The original viewBox, artwork paths and proportions are retained. Xcode preserves the PDF vector representation.
