# Geography data in Forma 1.6

The new subdivision layers retain their original licences independently. `geography-sources.json` gives each board's provider, original contributors, represented year, download URL, licence and licence-source URL. Each board JSON also carries a readable attribution, displayed in the app's Map data panel. No endorsement is implied.

Derived geometry is included in editable JSON/SVG-path form in `Boards/`, alongside its names and identifiers. Forma's modifications are reprojection, simplification, grouping by parent region, joining same-name fragments, and small-area markers. `Tools/build-geography.py` supplies the transformation recipe. The source distribution includes these adapted datasets without access restrictions.

Layers attributed to Open Data Commons Open Database Licence 1.0 are made available, including Forma's modifications, under ODbL 1.0: https://opendatacommons.org/licenses/odbl/1-0/ . Individual contents retain any separate rights identified in their source. This notice applies to the corresponding geographic databases, not unrelated app code.

Layers attributed to Creative Commons Attribution-ShareAlike remain under their corresponding licence, including Forma's adaptations:
- CC BY-SA 2.0: https://creativecommons.org/licenses/by-sa/2.0/
- CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/

Other per-layer terms (consult the manifest for the applicable layer):
- CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
- CC BY 3.0: https://creativecommons.org/licenses/by/3.0/
- CC BY 3.0 IGO: https://creativecommons.org/licenses/by/3.0/igo/
- CC BY 2.5: https://creativecommons.org/licenses/by/2.5/
- CC BY 2.5 India: https://creativecommons.org/licenses/by/2.5/in/
- CC0: https://creativecommons.org/publicdomain/zero/1.0/
- Open Government Licence 3.0: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
- Etalab Open Licence 2.0 and swisstopo: source-specific terms linked in the manifest.

Great Britain ceremonial county data: Contains OS data © Crown copyright and database right 2026. Ordnance Survey Boundary-Line, May 2026, Open Government Licence 3.0.

Ireland county data: Central Statistics Office, Government of Ireland, CC BY 4.0. Northern Ireland context is excluded from the 26-county quiz. The original file has no declared CRS; interpreting its coordinates as Irish Grid EPSG:29903 was checked against county locations before conversion.

Vietnam 2025 provinces: General Statistics Office of Vietnam, distributed by OCHA/HDX under CC BY 3.0 IGO. Adapted from the 34-province boundary dataset.

Virginia county and independent-city labels: US Census Bureau TIGERweb, public domain. These clarify names in geoBoundaries geometry; they do not replace its source boundaries.

Boundary editions vary. Source metadata dates describe the represented geometry, not the date this app imported it. These are educational source-edition maps, not a statement about sovereignty or a guarantee of current administrative boundaries. Known historical coverage is described in the source research notes and the app's boundary-edition label.


## Argentina and Namibia source corrections (18 October 2026)

Argentina's province quiz uses the IGN province WFS export captured on 18 October 2026. It contains 23 provinces and Buenos Aires city. The quiz retains its South American extent; Antarctic claims and separately quizzed South Atlantic territories are outside it. FUENTE: Instituto Geográfico Nacional de la República Argentina. Adapted and simplified for Forma; no endorsement is implied. The original export timestamp and metadata are retained in the source inputs. IGN permits reuse and modification with attribution, free redistribution of source data, and commercial derived products: https://www.ign.gob.ar/descargas/tyc1.html . The adapted source data is included without access restrictions in Tools/GeographyInputs/argentina-ign-20261018.geojson.

Namibia's fourteen-region geometry comes from the Namibia Statistics Agency, through OCHA HDX and geoBoundaries gbHumanitarian, pinned to geoBoundaries commit 9469f09. The source publication/update is 19 January 2023; its metadata gives 2011 as the geometry reference year. The target names and fourteen-region coverage were checked against the NSA 2023 Census. CC BY 3.0 IGO: https://creativecommons.org/licenses/by/3.0/igo/ . Source: https://data.humdata.org/dataset/cod-ab-nam . The adapted input and original metadata are included in Tools/GeographyInputs/namibia-nsa-2023.*.

The map-alignment context is derived from these and the separately attributed existing map layers. Alignment changes background context, preserving each quiz's answer outlines. Compressed context assets are fully reproducible with Tools/build-map-alignment.py and Tools/pack-map-alignment.swift.
