# Rebuilding geography

The editable derived data is shipped directly in `Content/Boards/`; no download is needed to build or use the app. `Content/geography-sources.json` records per-layer original download URLs, represented years, licences and SHA-256 hashes. `GEOGRAPHY-SOURCES-1.6.md` describes source-specific corrections and validation.

`build-geography.py --workspace <workspace>` was run using Python 3, numpy, shapely 2.1.2, pyproj 3.8 and pycountry 26.2.16. It expects the original project layout (`outputs/Forma-Native/Content`) and a `work` cache:

- `catalog-1.5.json`: the retained 29-board catalogue before this import.
- `geoboundaries-adm1-index.json`: metadata snapshot, deduplicated on valid ADM1 boundary IDs.
- `subdivisions/{ISO}-ADM1.geojson` and the selected ADM2/ADM3 files plus `{ISO}-{level}-metadata.json`.
- `subdivisions-extra/candidates.json`, the three official supplementary GeoJSON sources named by that manifest, and `usa-virginia-name-corrections.json`.

The small metadata and correction inputs are included in `GeographyInputs/`. Restore them into the above work paths before rerunning. Retrieve geometry from the recorded exact source URLs and compare hashes. geoBoundaries is pinned to commit 9469f09; use media.githubusercontent.com/media/wmgeolab/geoBoundaries/ rather than a Git LFS pointer returned by a raw source URL. The OS supplementary layer was converted from EPSG:27700 to EPSG:4326; the CSO layer is interpreted as EPSG:29903. See the research notes for official source retrieval and conversion details.

The generator validates shape names, coordinates, nonempty geometry and expected official county counts; dissolves same-name fragments; disambiguates Virginia names; assigns county polygons to parents; projects across the antimeridian; simplifies while preserving polygon topology; and writes attribution, audit, catalogue and directory data. The resulting app board JSON uses SVG path coordinates in a local projected canvas, not geographic longitude/latitude.

## Continuous maps (1.7.2)

All 278 geography boards use spherical Mercator coordinates. `mapReference` maps the shared unit-Mercator world into each board; world longitude wraps at the date line. `map-world.json` is the shared, offline Natural Earth context. Only board items accept answers. Small-area circles are now separate screen-sized rendering and hit-test overlays; they are not baked into geographic outlines.

Run `build-geography.py` as above, then `add-uk-countries.py`. Base maps and context can be rebuilt independently: from this Tools directory, install Node dependency `svgpath` (`npm install --no-save svgpath`) and run `node build-map-context.mjs`. Pinned input features are in `GeographyInputs/base-maps.json`; bundled D3 retains its upstream copyright header (ISC). Natural Earth is public domain. The base features retain the original app's board membership and source attribution.

## Display projections

Mercator remains the canonical editable geometry. `MapProjection.swift` derives a bounded render cache of Equal Earth paths from the stored `mapReference`; it does not rewrite or download boundaries. The spherical equations are those of Šavrič, Patterson & Jenny (2018), also implemented by PROJ (`https://proj.org/en/stable/operations/projections/eqearth.html`) and D3 (`https://github.com/d3/d3-geo/blob/main/src/projection/equalEarth.js`). Tests contain independently generated PROJ reference coordinates.

The converter clips rings and open borders at the selected central meridian's map seam before projection, preserves holes using even-odd fill, and adaptively subdivides segments to at most 0.002 board-point midpoint error. Regional central meridians use the nearest 15° to the original focus; World uses Greenwich. Source viewports determine regional focus, while World uses Equal Earth's full aspect ratio. The same conversion updates markers, decorations, split colour components and the existing subdivision context corrections. Equal Earth has one finite world rather than Mercator's repeated horizontal copies. Context tessellation covers the focus, remote answer components and letterboxed surrounding geography; the source files and all answer/progress IDs stay unchanged.

## Territories (1.14)

`node add-territories.mjs` (dependencies `svgpath` and `polygon-clipping`) builds two versions of each of the seven political maps from the untouched boards in `GeographyInputs/political-base/`, so it is safe to rerun:

- `<map>.json`, territories off: a territory counts as its owner when the owner is on the map (the Falklands and Greenland on World); otherwise it stays background.
- `<map>+territories.json`, territories on: every territory is its own answer labelled with its owner, e.g. "French Guiana (France)", and the owner loses those overseas parts. Viewports widen only to reach territories; Europe's is unchanged.

Both versions have Somaliland and Cyprus (North)/(South). Western Sahara, Antarctica and the Siachen Glacier stay background. Åland and uninhabited reefs and sub-Antarctic islands always count as their owner. The Canaries, Madeira, the Azores and Hawaii are integral regions, not territories. The script updates `catalog.json` counts for the off version; the on version is played through the in-app switch and never appears in the catalogue or Game Center.


## Four map colours

After regenerating geography boards, run `python3 Tools/build-map-colours.py` with Shapely 2.x installed. It derives shared borders from the local SVG paths, writes stable item assignments to `Content/map-colours.json`, and records the measured edges in `Tools/GeographyInputs/map-adjacency.json`. The test suite checks every edge against the four-colour assignments, including the USA/Greenland distinction.

Disconnected municipal exclaves can produce a non-planar answer graph. For these boards, the generator colours each connected shape separately and writes `Content/map-colour-parts.json`; drawing and thumbnails share these paths and assignments. No fifth colour is added. Re-run the generator when boundary geometry or target IDs change.

The generated four-colour assignments apply only to optional multicolour mode. Normal green mode retains its original six shades and stable ID assignments.

## Bristol coast display (1.14.0 build 43)

`fix-bristol-coast.py` uses the pinned ONS December 2025 Bristol BGC boundary (20m, clipped to Mean High Water), with URL, licence and SHA-256 in `GeographyInputs/bristol-coast-clipped-source.json`. It removes the OS ceremonial county's administrative Severn Estuary corridor from the displayed and tappable geometry. The county ID, 48-county membership and map frame remain unchanged. The main geography build runs this correction after generating the county boards; it can also be run independently.

## Region coverage and previews (build 44)

Continental coverage overlaps intentionally: Russia, Türkiye and both Cyprus targets occur on both Europe and Asia, with identical membership in their territory variants. Regional groupings retain the stated UN M49 conventions: Russia in Eastern Europe; Türkiye and both Cyprus targets in Western Asia and the explicitly curated Middle East. Both Cyprus targets always travel together in map membership; flag variants only include targets with a real flag entry. `LatestFeedbackTests` verifies these rules across the continental and regional decks. Reference: https://unstats.un.org/unsd/methodology/m49/.

Preview fitting and context coverage are separate. Asia's thumbnail is fitted to the established Asian core; adding Russia as an answer does not reframe it around the Arctic. The world-context renderer receives the full inverse-transformed visible card rectangle, including letterboxed margins, rather than only the quiz-fit box. This prevents Belgium and other surrounding countries from disappearing on wide England cards. Drawing continues to use the complete country shapes and the card clips at its outside edge.

## Six green shades (build 46)

After deriving `map-adjacency.json` with `build-map-colours.py`, run `python3 Tools/build-green-colours.py`. This uses the same measured border graph, retains an original green assignment where it is distinct enough, and assigns all six shades without matching neighbours. Disconnected pieces use the existing component geometry. The generated `map-green-colours.json` and `map-green-colour-parts.json` are separate from the optional four-colour map data. Light-mode green RGB values remain unchanged; dark greens have a wider lightness range. The shared tests verify all 15,742 measured borders for both palettes.


## Subdivision alignment and source audit (build 49)

After regenerating geography, run `fix-subdivision-sources.py` with Shapely 2.1.2 and numpy. It restores the pinned IGN Argentina and NSA/HDX Namibia layers, retains valid old answer identifiers, and updates the adjacency/colour data and attribution indexes for those two maps. See their retained source metadata in `GeographyInputs/`. Then run `build-map-alignment.py` with `DEVELOPER_DIR` pointing to Xcode. It derives per-quiz background corrections from the current answer geometry, preserves land joins and unrelated countries, and suppresses duplicate coarse outlines. A bounded lazy cache reads individual LZFSE assets from `Content/MapAlignment/`; a temporary build cache lives in `.build/`. `pack-map-alignment.swift` verifies each compressed asset by round trip. All geographic source outlines remain unchanged during this context build.

`MapAlignmentTests` checks every subdivision's context ownership, source-interior coverage and the titles/counts of all 289 geography quizzes. Set `FORMA_GEOGRAPHY_REVIEW` to a folder to retain all 578 light/dark preview renders and `quiz-audit.json`. The native debug fixture also captures country, state/county and date-line examples in both appearances.
