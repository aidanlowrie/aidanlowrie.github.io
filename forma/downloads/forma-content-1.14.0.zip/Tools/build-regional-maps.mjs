// Rebuild curated regional decks from the bundled Natural Earth source geometry.
// Requires svgpath (npm install --no-save svgpath).
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const dir=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(dir,'../Content');
const require=createRequire(import.meta.url);
let svgpath;try { svgpath=require('svgpath'); } catch { svgpath=require(path.resolve(dir,'../../../work/native-builder/node_modules/svgpath')); }
const read=p=>JSON.parse(fs.readFileSync(p));
const write=(p,d)=>fs.writeFileSync(p,JSON.stringify(d));
const inputs=read(`${dir}/GeographyInputs/base-maps.json`), ctx=vm.createContext({});
vm.runInContext(fs.readFileSync(`${dir}/GeographyInputs/d3.min.js`,'utf8'),ctx);
const d3=ctx.d3, places=read(`${root}/places.json`).filter(p=>!p.code.startsWith('region:'));
const world=read(`${root}/Boards/world.json`), source=inputs.boards.find(b=>b.board.id==='world').items;
const codeFor=id=>places.find(p=>p.id===({PSX:'PSE',KOS:'XKX',SDS:'SSD'}[id]||id))?.code;
const specs=[
 ['middle-east','Middle East','Asia','BH CY EG IR IQ IL JO KW LB OM PS QA SA SY TR AE YE','Curated coverage including Egypt, Iran, Türkiye and Cyprus; regional definitions vary.'],
 ['north-africa','North Africa','Africa','DZ EG LY MA SD TN','Based on UN Northern Africa. Western Sahara is shown as context but is not an answer in this edition.'],
 ['east-asia','East Asia','Asia','CN JP KP KR MN TW','Based on UN Eastern Asia, with Taiwan separately represented; Hong Kong and Macao are not separate answers.'],
 ['southeast-asia','Southeast Asia','Asia','BN KH ID LA MY MM PH SG TH TL VN',null],
 ['south-asia','South Asia','Asia','AF BD BT IN IR MV NP PK LK',null],
 ['central-asia','Central Asia','Asia','KZ KG TJ TM UZ',null],
 ['western-asia','Western Asia','Asia','AM AZ BH CY GE IQ IL JO KW LB OM QA SA PS SY TR AE YE',null],
 ['northern-europe','Northern Europe','Europe','DK EE FI IS IE LV LT NO SE GB','Based on UN Northern Europe; dependent territories are not separate answers.'],
 ['western-europe','Western Europe','Europe','AT BE FR DE LI LU MC NL CH',null],
 ['eastern-europe','Eastern Europe','Europe','BY BG CZ HU PL MD RO RU SK UA',null],
 ['southern-europe','Southern Europe','Europe','AL AD BA HR GR VA IT MT ME MK PT SM RS SI ES XK','Based on UN Southern Europe, with Kosovo separately represented; Gibraltar is not a separate answer.']
];
let catalog=read(`${root}/catalog.json`).filter(b=>!specs.some(s=>s[0]===b.id));
const regions=[];
for(const [id,title,continent,codes,note] of specs){
 const members=codes.split(' '), raw=source.filter(i=>members.includes(codeFor(i.id)));
 if(raw.length!==members.length)throw Error(`Missing members: ${id}`);
 // Match the political maps: both parts of Cyprus belong to a region containing Cyprus.
 if(raw.some(r=>r.id==='CYP')){
  const north=inputs.world.features.find(f=>f.properties.NAME_EN==='Turkish Republic of Northern Cyprus');
  if(!north)throw Error('Missing northern Cyprus geometry');
  raw.push({id:'CYN',feature:north});
 }
 const collection={type:'FeatureCollection',features:raw.map(r=>r.feature)};
 // Russia's distant eastern islands must not shrink the Eastern Europe view.
 const p=d3.geoMercator();
 if(id==='eastern-europe')p.center([38,55]).scale(570).translate([450,320]);
 else p.fitExtent([[28,28],[872,612]],collection);
 const draw=d3.geoPath(p).digits(5), k=p.scale(),t=p.translate(),c=p.center();
 const info={id,title,domain:'geography',type:'map',description:note||'UN M49 regional grouping.',label:'REGIONAL MAP',unit:'places',flags:false,count:raw.length,continent,keywords:title+' '+members.map(code=>places.find(p=>p.code===code)?.name||code).join(' '),regionCode:'region:'+id,coveredCountries:members};
 const items=raw.map(r=>{const original=world.items.find(i=>i.id===r.id), xy=r.coord?p(r.coord):draw.centroid(r.feature);return {...original,path:svgpath(draw(r.feature)).unarc().unshort().abs().round(5).toString(),x:xy[0],y:xy[1],marker:r.id==='CYP'||r.id==='CYN'||draw.area(r.feature)<80};});
 const b=draw.bounds(collection), viewport=id==='eastern-europe'?[0,0,900,640]:[b[0][0]-12,b[0][1]-12,b[1][0]-b[0][0]+24,b[1][1]-b[0][1]+24];
 write(`${root}/Boards/${id}.json`,{info,items,background:'',graticule:'',decor:[],viewport,mapReference:{scale:k*2*Math.PI,x:t[0]-k*c[0]*Math.PI/180,y:t[1]+k*Math.log(Math.tan(Math.PI/4+c[1]*Math.PI/360))},source:'Natural Earth (public domain); UN M49 with stated coverage adaptations.',sourceURL:'https://unstats.un.org/unsd/methodology/m49/'});
 catalog.push(info);regions.push({id,code:'region:'+id,name:title,continent,aliases:[],note:note||'UN M49 regional grouping.',flagOverride:'',memberCountries:members});
}
for(const id of ['europe','asia','africa','north-america','south-america','oceania']){
 const b=read(`${root}/Boards/${id}.json`), members=[...new Set(b.items.map(i=>codeFor(i.id)).filter(Boolean))];
 b.info.regionCode='region:'+id;b.info.coveredCountries=members;write(`${root}/Boards/${id}.json`,b);
 catalog[catalog.findIndex(x=>x.id===id)]=b.info;
 regions.push({id,code:'region:'+id,name:b.info.title,continent:b.info.title,aliases:[],note:null,flagOverride:'',memberCountries:members});
}
// Explicit relationships support region interests without turning a continent's
// hundreds of subdivisions into equally relevant recommendations.
for(const info of catalog){
 const countries=info.coveredCountries||[...(info.relatedCountries||[]),info.countryCode].filter(Boolean);
 info.relatedRegions=regions.filter(r=>countries.some(c=>r.memberCountries.includes(c))).map(r=>r.code);
 const f=`${root}/Boards/${info.id}.json`,b=read(f);b.info=info;write(f,b);
}
write(`${root}/catalog.json`,catalog);write(`${root}/places.json`,[...places,...regions].sort((a,b)=>a.name.localeCompare(b.name)));
console.log(`Built ${specs.length} regional maps and ${regions.length} regional interests.`);
