// Builds two versions of each political map from GeographyInputs/political-base:
//   <board>.json               territories off: a territory counts as its owner when the
//                              owner is on the board; otherwise it stays background.
//   <board>+territories.json   territories on: every territory is its own answer,
//                              labelled with its owner in brackets.
// Somaliland and Cyprus (North) are answers in both; Western Sahara is an explicitly disputed answer only with territories on.
// Run from this Tools directory: npm install --no-save svgpath polygon-clipping && node add-territories.mjs
// Safe to rerun: it always starts from the base boards.
import fs from 'node:fs';
import vm from 'node:vm';
import {createRequire} from 'node:module';
const require=createRequire(process.env.MODULES_DIR?process.env.MODULES_DIR+'/':import.meta.url);
const svgpath=require('svgpath'),clip=require('polygon-clipping');
const root='../Content';
const inputs=JSON.parse(fs.readFileSync('GeographyInputs/base-maps.json'));
const context=vm.createContext({});
vm.runInContext(fs.readFileSync('GeographyInputs/d3.min.js','utf8'),context);
const d3=context.d3;
const norm=d=>d?svgpath(d).unarc().unshort().abs().round(5).toString():'';
// Map-unit supplement fills tiny territories absent from the original country layer.
const supplement=JSON.parse(fs.readFileSync('GeographyInputs/territory-supplement.json'));
const world=Object.fromEntries([...inputs.world.features,...supplement.features].map(f=>[f.properties.NAME_EN,f]));
const polygons=g=>g.type==='MultiPolygon'?g.coordinates:[g.coordinates];
const inside=box=>p=>p[0].every(([x,y])=>x>=box[0]&&x<=box[2]&&y>=box[1]&&y<=box[3]);
const feature=(name,box,keep=true)=>{
 const f=world[name];if(!f)throw Error(`missing feature ${name}`);
 if(!box)return f;
 // With keep, the polygons inside [west,south,east,north]; otherwise the rest.
 const kept=polygons(f.geometry).filter(p=>inside(box)(p)===keep);
 if(!kept.length)throw Error(`${name}: no polygons for ${box}`);
 return {type:'Feature',properties:f.properties,geometry:{type:'MultiPolygon',coordinates:kept}};
};
const flag=code=>code&&/^[A-Z]{2}$/.test(code)?String.fromCodePoint(...[...code].map(c=>0x1F1A5+c.charCodeAt(0))):'';

// Overseas parts inside a sovereign country's own feature.
const SPLITS={France:{GUF:[-55,2,-51,6],GLP:[-62,15.8,-61,16.6],MTQ:[-61.3,14.3,-60.8,14.9],REU:[55,-21.5,56,-20.8],MYT:[44.9,-13.1,45.3,-12.6]},Netherlands:{BES:[-69,12,-62,18]},Portugal:{AZO:[-32,36,-24,40],MDR:[-18,32,-16,34]},Spain:{CNI:[-19,27,-13,30]},Norway:{SVA:[8,74,37,82]},'New Zealand':{TKL:[-173,-10,-171,-8]}};
const SPLIT_OWNER={FRA:'France',NLD:'Netherlands',PRT:'Portugal',ESP:'Spain',NOR:'Norway',NZL:'New Zealand'};
// id: [label, owner item id, feature name or [owner feature, box], extra aliases, ISO code].
const T={
 ALA:['Åland (Finland)','FIN','Åland',['Aland','Åland Islands','Aland Islands'],'AX'],
 SVA:['Svalbard (Norway)','NOR',['Norway'],['Spitsbergen'],'SJ'],
 GIB:['Gibraltar (UK)','GBR','Gibraltar',[],'GI'],
 TKL:['Tokelau (New Zealand)','NZL','Tokelau',[],'TK'],
 AZO:['Azores (Portugal)','PRT',['Portugal'],['Açores','Acores'],'PT'],
 MDR:['Madeira (Portugal)','PRT',['Portugal'],[],'PT'],
 CNI:['Canary Islands (Spain)','ESP',['Spain'],['Canaries','Islas Canarias'],'ES'],
 ESH:['Western Sahara (Disputed)',null,'Western Sahara',['Western Sahara','Sahrawi Arab Democratic Republic'],''],
 GRL:['Greenland (Denmark)','DNK','Greenland',[],'GL'],FRO:['Faroe Islands (Denmark)','DNK','Faroe Islands',['Faroes','Faeroe Islands'],'FO'],
 JEY:['Jersey (Crown Dependency)','GBR','Jersey',[],'JE'],GGY:['Guernsey (Crown Dependency)','GBR','Guernsey',[],'GG'],IMN:['Isle of Man (Crown Dependency)','GBR','Isle of Man',[],'IM'],
 BMU:['Bermuda (UK)','GBR','Bermuda',[],'BM'],CYM:['Cayman Islands (UK)','GBR','Cayman Islands',['Caymans'],'KY'],
 TCA:['Turks and Caicos Islands (UK)','GBR','Turks and Caicos Islands',['Turks and Caicos'],'TC'],
 VGB:['British Virgin Islands (UK)','GBR','British Virgin Islands',[],'VG'],AIA:['Anguilla (UK)','GBR','Anguilla',[],'AI'],MSR:['Montserrat (UK)','GBR','Montserrat',[],'MS'],
 FLK:['Falkland Islands (UK)','GBR','Falkland Islands',['Falklands','Malvinas','Islas Malvinas'],'FK'],
 SGS:['South Georgia (UK)','GBR','South Georgia and the South Sandwich Islands',['South Georgia and the South Sandwich Islands'],'GS'],
 SHN:['Saint Helena (UK)','GBR','Saint Helena',['St Helena','Ascension'],'SH'],
 IOT:['Chagos Islands (UK)','GBR','British Indian Ocean Territory',['British Indian Ocean Territory','BIOT','Diego Garcia'],'IO'],
 PCN:['Pitcairn Islands (UK)','GBR','Pitcairn Islands',['Pitcairn'],'PN'],
 ABW:['Aruba (Netherlands)','NLD','Aruba',[],'AW'],CUW:['Curaçao (Netherlands)','NLD','Curaçao',['Curacao'],'CW'],SXM:['Sint Maarten (Netherlands)','NLD','Sint Maarten',[],'SX'],
 BES:['Caribbean Netherlands','NLD',['Netherlands'],['Bonaire','Sint Eustatius','Saba','Bonaire, Sint Eustatius and Saba'],'BQ'],
 MAF:['Saint Martin (France)','FRA','Saint Martin',['St Martin','St. Martin'],'MF'],BLM:['Saint Barthélemy (France)','FRA','Saint Barthélemy',['St Barts','St Barths','Saint Barthelemy'],'BL'],
 SPM:['Saint Pierre and Miquelon (France)','FRA','Saint Pierre and Miquelon',['St Pierre and Miquelon'],'PM'],
 GLP:['Guadeloupe (France)','FRA',['France'],[],'GP'],MTQ:['Martinique (France)','FRA',['France'],[],'MQ'],GUF:['French Guiana (France)','FRA',['France'],['Guyane','French Guyana'],'GF'],
 REU:['Réunion (France)','FRA',['France'],['Reunion'],'RE'],MYT:['Mayotte (France)','FRA',['France'],[],'YT'],
 NCL:['New Caledonia (France)','FRA','New Caledonia',[],'NC'],PYF:['French Polynesia (France)','FRA','French Polynesia',['Tahiti'],'PF'],WLF:['Wallis and Futuna (France)','FRA','Wallis and Futuna',[],'WF'],
 PRI:['Puerto Rico (US)','USA','Puerto Rico',[],'PR'],VIR:['US Virgin Islands (US)','USA','United States Virgin Islands',['United States Virgin Islands'],'VI'],
 GUM:['Guam (US)','USA','Guam',[],'GU'],MNP:['Northern Mariana Islands (US)','USA','Northern Mariana Islands',['Northern Marianas'],'MP'],ASM:['American Samoa (US)','USA','American Samoa',[],'AS'],
 COK:['Cook Islands (New Zealand)','NZL','Cook Islands',[],'CK'],NIU:['Niue (New Zealand)','NZL','Niue',[],'NU'],
 NFK:['Norfolk Island (Australia)','AUS','Norfolk Island',[],'NF'],
 CXR:['Christmas Island (Australia)','AUS',['Australian Indian Ocean Territories',[105,-11,106,-10]],[],'CX'],
 CCK:['Cocos (Keeling) Islands (Australia)','AUS',['Australian Indian Ocean Territories',[96.8,-12.3,97,-12.1]],['Cocos Islands','Keeling Islands'],'CC'],
 HKG:['Hong Kong (China)','CHN','Hong Kong',[],'HK'],MAC:['Macau (China)','CHN','Macau',['Macao'],'MO'],
};
// Uninhabited reefs and sub-Antarctic islands stay part of their owner.
const ALWAYS_MERGED={AUS:['Ashmore and Cartier Islands','Heard Island and McDonald Islands'],FRA:['French Southern and Antarctic Lands']};
// Answers in both versions.
const STATES={SOL:['Somaliland','Somaliland',[],''],CYN:['Cyprus (North)','Turkish Republic of Northern Cyprus',['Northern Cyprus','North Cyprus','TRNC'],'']};
const TERRITORIES_BY_BOARD={
 europe:['FRO','JEY','GGY','IMN','AZO','MDR','CNI','ALA','SVA','GIB'],
 'north-america':['GRL','BMU','CYM','TCA','VGB','AIA','MSR','ABW','CUW','SXM','BES','MAF','BLM','SPM','GLP','MTQ','PRI','VIR'],
 'south-america':['GUF','FLK','SGS'],
 africa:['SHN','REU','MYT','AZO','MDR','CNI','ESH'],
 asia:['HKG','MAC','CXR','CCK','IOT'],
 oceania:['COK','NIU','NCL','PYF','WLF','GUM','MNP','ASM','PCN','NFK','TKL'],
};
TERRITORIES_BY_BOARD.world=Object.keys(T);
const STATES_BY_BOARD={africa:['SOL'],asia:['CYN'],europe:['CYN'],world:['SOL','CYN']};
const COPIES={europe:['CYP','TUR'],asia:['RUS']};
const ROTATION={oceania:155,us:-130};
// Frames chosen by eye for territories on. Africa opens zoomed out, from Cape Verde to
// past Mauritius with southern Europe in view, so the ocean islands sit comfortably inside.
const FRAMES={africa:[65,-33,724,700]};
const baseDir='GeographyInputs/political-base';
const worldBase=JSON.parse(fs.readFileSync(`${baseDir}/world.json`));
const worldFeatures=inputs.boards.find(e=>e.board.id==='world').items;
const catalog=JSON.parse(fs.readFileSync(`${root}/catalog.json`));
const territoryFeature=id=>{const s=T[id][2];return Array.isArray(s)?(s.length===1?feature(s[0],SPLITS[s[0]][id]):feature(...s)):feature(s)};
const report=[];
for(const id of Object.keys(TERRITORIES_BY_BOARD)){
 const base=JSON.parse(fs.readFileSync(`${baseDir}/${id}.json`));
 const ref=base.mapReference,rot=ROTATION[id]||0,k=ref.scale/(2*Math.PI);
 const p=d3.geoMercator().rotate([-rot,0]).scale(k).translate([ref.x+k*rot*Math.PI/180,ref.y]);
 const path=d3.geoPath(p).digits(5);
 const raw=inputs.boards.find(e=>e.board.id===id).items;
 if(!raw.some(r=>r.feature&&base.items.find(x=>x.id===r.id)?.path===norm(path(r.feature))))throw Error(`${id}: projection does not reproduce stored paths`);
 const made=f=>{const d=norm(path(f)),xy=path.centroid(f);if(!d||!xy.every(Number.isFinite))throw Error(`${id}: bad geometry`);return {d,xy,marker:path.area(f)<80}};
 // The bracket is the owner, so the plain name is also an answer; not for Cyprus (North).
 const item=(key,name,f,aliases,code,plain=true)=>{const g=made(f);return {id:key,name,aliases:[...new Set([...(plain?[name.replace(/ \((.*)\)$/,'')]:[name]),...aliases])],fact:key==='ESH'?'Disputed territory. Final status remains unresolved.':`${f.properties.SUBREGION}.`,flag:flag(code),path:g.d,x:g.xy[0],y:g.xy[1],fill:'#bdcfda',symbol:'',number:null,marker:g.marker}};
 for(const territories of [false,true]){
  const data=structuredClone(base),byID=x=>data.items.find(i=>i.id===x);
  const insert=v=>{const at=data.items.findIndex(x=>x.name.localeCompare(v.name)>0);data.items.splice(at<0?data.items.length:at,0,v)};
  const answers=new Set(data.items.map(i=>i.id));
  for(const key of COPIES[id]||[]){const src=worldBase.items.find(x=>x.id===key),g=made(worldFeatures.find(r=>r.id===key).feature);insert({...src,path:g.d,x:g.xy[0],y:g.xy[1],marker:g.marker});answers.add(key)}
  for(const key of STATES_BY_BOARD[id]||[]){const [name,src,aliases,code]=STATES[key];insert(item(key,name,feature(src),aliases,code,false))}
  const extra={},union={};
  for(const [owner,names] of Object.entries(ALWAYS_MERGED))if(answers.has(owner))(extra[owner]??=[]).push(...names.map(n=>feature(n)));
  for(const key of TERRITORIES_BY_BOARD[id]){
   const [name,owner,,aliases,code]=T[key],f=territoryFeature(key);
   if(territories)insert(item(key,name,f,aliases,code));
   else if(answers.has(owner)){
    // France's and the Netherlands' overseas parts are already in their outline.
    if((Array.isArray(T[key][2])&&T[key][2].length===1)||key==='TKL')continue;
    // Land borders are dissolved so no internal line is drawn.
    (owner==='CHN'?union:extra)[owner]??=[];(owner==='CHN'?union:extra)[owner].push(f);
   }
  }
  // The old base maps omitted some Atlantic islands; restore their owner geometry off.
  if(!territories)for(const owner of ['PRT','ESP','NOR','NZL']){
   const own=byID(owner);if(own)own.path=norm(path(world[SPLIT_OWNER[owner]]));
  }
  // With territories on, the owner loses the overseas parts that became answers.
  if(territories)for(const [owner,name] of Object.entries(SPLIT_OWNER)){
   const own=byID(owner);if(!own)continue;
   const taken=Object.entries(SPLITS[name]).filter(([key])=>TERRITORIES_BY_BOARD[id].includes(key)).map(([,box])=>box);
   if(!taken.length)continue;
   const rest=polygons(world[name].geometry).filter(q=>!taken.some(box=>inside(box)(q)));
   own.path=norm(path({type:'Feature',properties:{},geometry:{type:'MultiPolygon',coordinates:rest}}));
  }
  for(const [owner,fs_] of Object.entries(extra))byID(owner).path+=' '+fs_.map(f=>norm(path(f))).join(' ');
  for(const [owner,fs_] of Object.entries(union)){
   const own=raw.find(r=>r.id===owner).feature;
   // polygon-clipping returns counter-clockwise outer rings; d3 reads those as the
   // rest of the sphere, so reverse them back to d3's winding.
   const merged=clip.union(polygons(own.geometry),...fs_.map(f=>polygons(f.geometry))).map(q=>q.map(r=>[...r].reverse()));
   byID(owner).path=norm(path({type:'Feature',properties:{},geometry:{type:'MultiPolygon',coordinates:merged}}));
  }
  const cyprus=byID('CYP');
  if(cyprus&&byID('CYN')){
   Object.assign(cyprus,{name:'Cyprus (South)',aliases:[...new Set(['Cyprus','South Cyprus','Republic of Cyprus',...cyprus.aliases])]});
   // The renderer separates this pair on screen at low zoom, with geographic leaders.
   cyprus.marker=true;byID('CYN').marker=true;
  }
  if(territories){
   // Every territory must be reachable: the camera can't leave the viewport.
   let [x0,y0,w,h]=FRAMES[id]??data.viewport,x1=x0+w,y1=y0+h;
   for(const v of data.items.filter(v=>T[v.id])){
    const [[left,top],[right,bottom]]=path.bounds(territoryFeature(v.id));
    x0=Math.min(x0,v.x-30,left-18);y0=Math.min(y0,v.y-30,top-18);
    x1=Math.max(x1,v.x+30,right+18);y1=Math.max(y1,v.y+30,bottom+18);
   }
   data.viewport=[x0,y0,x1-x0,y1-y0];
   data.info={...data.info,id:`${id}+territories`,title:`${data.info.title} · territories`,unit:"countries and territories"};
  }
  data.info.count=data.items.length;
  if(data.info.coveredCountries)data.info.coveredCountries=[...new Set([...data.info.coveredCountries,...(COPIES[id]||[]).map(key=>worldFeatures.find(r=>r.id===key).feature.properties.ISO_A2_EH)])];
  const file=`${root}/Boards/${data.info.id}.json`;
  fs.writeFileSync(file,JSON.stringify(data));
  if(!territories){const entry=catalog.find(b=>b.id===id);entry.count=data.info.count;if(data.info.coveredCountries)entry.coveredCountries=data.info.coveredCountries}
  report.push(`${data.info.id}: ${data.items.length} answers, viewport ${data.viewport.map(v=>Math.round(v)).join(',')}`);
 }
}
fs.writeFileSync(`${root}/catalog.json`,JSON.stringify(catalog));
console.log(report.join('\n'));
