"""Assign six green shades from the already measured offline border graph. No geometry dependencies."""
from pathlib import Path
from collections import defaultdict
import json, math
ROOT=Path(__file__).resolve().parents[1]
DARK=['8FB59D','B0CCB8','789F88','A0BDA2','90B8AB','C4D8C9']
def lab(h):
 rgb=[int(h[i:i+2],16)/255 for i in (0,2,4)]
 r,g,b=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
 xyz=[(.4124564*r+.3575761*g+.1804375*b)/.95047,.2126729*r+.7151522*g+.0721750*b,(.0193339*r+.1191920*g+.9503041*b)/1.08883]
 x,y,z=[v**(1/3) if v>.008856 else 7.787*v+16/116 for v in xyz]
 return 116*y-16,500*(x-y),200*(y-z)
colours=[lab(h) for h in DARK]
def difference(a,b):return math.dist(colours[a],colours[b])
def original(ident):
 if ident=='USA':return 0
 if ident=='GRL':return 1
 value=14695981039346656037
 for v in ident.encode():value=((value^v)*1099511628211)&((1<<64)-1)
 return value%6
edges=json.loads((ROOT/'Tools/GeographyInputs/map-adjacency.json').read_text())['edges']
graph=defaultdict(set)
for a,b in edges:graph[a].add(b);graph[b].add(a)
assigned={'USA':0,'GRL':1}
remaining=set(graph)-set(assigned)
while remaining:
 node=max(remaining,key=lambda n:(len({assigned[v] for v in graph[n] if v in assigned}),len(graph[n]),n))
 used={assigned[v] for v in graph[node] if v in assigned}
 choices=set(range(6))-used
 if not choices:raise RuntimeError('Six-colour conflict: '+node)
 preferred=original(node.split('#')[0])
 def separation(c):return min((difference(c,v) for v in used),default=100)
 # Retain an original shade where it is distinct enough; otherwise increase
 # separation from the neighbours already assigned. Ties stay deterministic.
 if preferred in choices and separation(preferred)>=8:choice=preferred
 else:choice=max(choices,key=lambda c:(separation(c),-abs(c-preferred),-c))
 assigned[node]=choice;remaining.remove(node)
assert all(assigned[a]!=assigned[b] for a,b in edges)
for path in (ROOT/'Content/Boards').glob('*.json'):
 board=json.loads(path.read_text())
 if board['info']['domain']=='geography':
  for item in board['items']:assigned.setdefault(item['id'],original(item['id']))
parts=json.loads((ROOT/'Content/map-colour-parts.json').read_text())
for ident,values in parts.items():
 for i,value in enumerate(values):value['index']=assigned[f'{ident}#{i}']
 assigned[ident]=assigned[f'{ident}#0']
(ROOT/'Content/map-green-colours.json').write_text(json.dumps(dict(sorted(assigned.items())),separators=(',',':'))+'\n')
(ROOT/'Content/map-green-colour-parts.json').write_text(json.dumps(parts,separators=(',',':'))+'\n')
separations=sorted(difference(assigned[a],assigned[b]) for a,b in edges)
print(f'{len(edges)} shared borders; zero equal green neighbours; all {len(set(assigned.values()))} shades used; dark Delta E min {separations[0]:.2f}, median {separations[len(separations)//2]:.2f}')
