"""Align detailed subdivision maps with offline world context. Requires Shapely 2.1.2.
Target outlines are read unchanged. Context replaces its coarse copy of the active
scope; nearest-boundary Voronoi cells retain land at international joins without
retaining a second coarse coastline. Source-edition boundaries remain explicit.
"""
import json,re,math,collections,hashlib,subprocess
from pathlib import Path
from shapely.geometry import Polygon,MultiPoint,Point,GeometryCollection,box
from shapely import make_valid,union_all,voronoi_polygons,set_precision
from shapely.affinity import affine_transform,translate
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1]
TOKEN=re.compile(r'[MmLlHhVvZz]|-?\d*\.?\d+(?:[eE][-+]?\d+)?')
def geometry(path):
 t=TOKEN.findall(path); rings=[]; ring=[];i=0;cmd=None;x=y=0
 def finish():
  if len(ring)>2:
   p=make_valid(Polygon(ring)).buffer(0)
   if not p.is_empty:
    signed=sum(ring[k][0]*ring[(k+1)%len(ring)][1]-ring[(k+1)%len(ring)][0]*ring[k][1] for k in range(len(ring)))
    rings.append((p,signed))
 while i<len(t):
  if t[i].isalpha():
   cmd=t[i];i+=1
   if cmd.upper()=='Z':finish();ring=[];continue
  if cmd.upper() in ('M','L'):
   a,b=float(t[i]),float(t[i+1]);i+=2
   if cmd.islower():a+=x;b+=y
   x,y=a,b
   if cmd.upper()=='M':
    if ring:finish();ring=[]
    cmd='l' if cmd.islower() else 'L'
   ring.append((x,y))
  elif cmd.upper()=='H':
   a=float(t[i]);i+=1;x=a+x if cmd.islower() else a;ring.append((x,y))
  elif cmd.upper()=='V':
   a=float(t[i]);i+=1;y=a+y if cmd.islower() else a;ring.append((x,y))
  else:raise ValueError(cmd)
 if ring:finish()
 if not rings:return None
 sign=max(rings,key=lambda pair:abs(pair[1]))[1]>0
 value=union_all([p for p,a in rings if (a>0)==sign])
 holes=[p for p,a in rings if (a>0)!=sign]
 if holes:value=value.difference(union_all(holes))
 return make_valid(value).buffer(0)

def pieces(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for child in getattr(g,'geoms',[]) for p in pieces(child)]
def svg(g):
 if g is None or g.is_empty:return ""
 paths=[]
 def ring(coords,closed):
  pts=list(coords)
  if len(pts)>1:paths.append('M'+'L'.join(f'{x:.10f},{y:.10f}' for x,y in pts)+('Z' if closed else ''))
 def visit(value):
  if value.geom_type=='Polygon':
   ring(value.exterior.coords,True)
   for h in value.interiors:ring(h.coords,True)
  elif value.geom_type in ['LineString','LinearRing']:ring(value.coords,False)
  else:
   for child in getattr(value,'geoms',[]):visit(child)
 visit(g);return ''.join(paths)
cache={}
def board_shapes(data):
 ref=data['mapReference'];scale=ref['scale']
 values=[]
 for item in data['items']:
  key=item['path']
  if key not in cache:cache[key]=geometry(key)
  if cache[key] is None:
   print('EMPTY_SHAPE',data['info']['id'],item['id'],item['name'],flush=True);continue
  g=affine_transform(cache[key],[1/scale,0,0,1/scale,-ref['x']/scale,-ref['y']/scale])
  values.append((item,set_precision(make_valid(g).buffer(0),1e-10)))
 return values
world=json.loads((ROOT/'Content/map-world.json').read_text())
world=[dict(name=v['name'],shape=geometry(v['path'])) for v in world]
base=json.loads((ROOT/'Tools/GeographyInputs/base-maps.json').read_text())
codes={f['properties']['NAME_EN']:f['properties'].get('ISO_A2_EH') for f in base['world']['features']}
places=json.loads((ROOT/'Content/places.json').read_text());iso={p['id']:p['code'] for p in places}
for f in base['world']['features']:
 if f['properties'].get('ADM0_A3') in iso:codes[f['properties']['NAME_EN']]=iso[f['properties']['ADM0_A3']]
for w in world:w['code']=codes.get(w['name'])
def gap_land(old,new,neighbours,tolerance=2e-8):
 difference=old.difference(new)
 # Interior holes introduced by the detailed source are lakes or omitted areas,
 # not strips between two versions of an international boundary.
 difference=union_all([g for g in pieces(difference) if g.distance(old.boundary)<tolerance])
 if difference.is_empty or neighbours.is_empty:return GeometryCollection()
 samples=[];inland=[]
 for poly in pieces(old):
  for boundary in [poly.exterior,*poly.interiors]:
   coords=list(boundary.coords)
   for a,b in zip(coords,coords[1:]):
    n=max(1,math.ceil(math.dist(a,b)/max(old.length/1500,1e-7)))
    for i in range(n):
     p=Point(a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n)
     samples.append(p);inland.append(p.distance(neighbours)<tolerance)
 if not any(inland):return GeometryCollection()
 # Coincident sites can occur at shared ring vertices.
 unique={tuple(p.coords)[0]:label for p,label in zip(samples,inland)}
 sites=MultiPoint(list(unique));cells=voronoi_polygons(sites,ordered=True)
 return union_all([cell.intersection(difference) for cell,keep in zip(cells.geoms,unique.values()) if keep])
def gap_parts(old,new,neighbours,window,tolerance=2e-8):
 difference=union_all([g for g in pieces(old.difference(new)) if g.distance(old.boundary)<tolerance]).intersection(window)
 if difference.is_empty or not neighbours:return [GeometryCollection() for _ in neighbours]
 tree=STRtree(neighbours);sites={}
 for poly in pieces(old):
  for boundary in [poly.exterior,*poly.interiors]:
   coords=list(boundary.coords)
   for a,b in zip(coords,coords[1:]):
    n=max(1,math.ceil(math.dist(a,b)/max(old.length/1500,1e-7)))
    for i in range(n):
     point=Point(a[0]+(b[0]-a[0])*i/n,a[1]+(b[1]-a[1])*i/n)
     matches=tree.query(point,predicate='dwithin',distance=tolerance)
     sites[tuple(point.coords)[0]]=int(matches[0]) if len(matches) else None
 cells=voronoi_polygons(MultiPoint(list(sites)),ordered=True);groups=[[] for _ in neighbours]
 for cell,label in zip(cells.geoms,sites.values()):
  if label is not None:groups[label].append(cell.intersection(difference))
 return [union_all(values) for values in groups]

patches={};audit=[]
cachefile=ROOT/'.build/map-alignment-cache.json'
checkpoint=json.loads(cachefile.read_text()) if cachefile.exists() else {}
worldhash=hashlib.sha256((ROOT/'Content/map-world.json').read_bytes()).hexdigest()
catalog=json.loads((ROOT/'Content/catalog.json').read_text())
for info in catalog:
 if info['domain']!='geography' or not info.get('countryCode') or info['type']=='points':continue
 raw=(ROOT/f"Content/Boards/{info['id']}.json").read_bytes()
 parentraw=(ROOT/f"Content/Boards/{info['parentBoardID']}.json").read_bytes() if info.get('parentBoardID') else b''
 signature=hashlib.sha256(raw+parentraw+worldhash.encode()+b'alignment-v3').hexdigest()
 saved=checkpoint.get(info['id'])
 if saved and saved['signature']==signature:
  patches[info['id']]=saved['patch'];audit.append(saved['audit']);print(info['id'],'cached',flush=True);continue
 data=json.loads(raw)
 if not data.get('mapReference'):continue
 shapes=board_shapes(data);target=union_all([g for _,g in shapes]);centre=target.centroid.x
 def near(g):return union_all([translate(poly,xoff=round(centre-poly.centroid.x)) for poly in pieces(g)])
 owners=[w for w in world if w['code']==info['countryCode']]
 parent=None;active=None;others=GeometryCollection()
 if info.get('parentBoardID') in ['us','regions-gbr']:
  parent=json.loads((ROOT/f"Content/Boards/{info['parentBoardID']}.json").read_text())
  parent_shapes=board_shapes(parent);title=info['title'].split(' · ')[0]
  matches=[(i,g) for i,g in parent_shapes if i['name']==title]
  if matches:
   active=near(matches[0][1]);others=union_all([near(g) for i,g in parent_shapes if i['name']!=title])
  else:
   # Territories have countryCode US but are not one of its fifty states.
   choices=[(near(w['shape']).intersection(target).area,w) for w in world]
   best=max(choices,key=lambda x:x[0])
   if best[0]>0:owners=[best[1]]
 owner=union_all([near(w['shape']) for w in owners])
 if owner.is_empty:raise ValueError(('Unmatched country',info['id'],info['countryCode']))
 if active is not None:
  coarse=owner;scope=active;remote=[]
 else:
  selected=[];remote=[]
  for poly in pieces(owner):
   (selected if poly.intersects(target) or poly.distance(target)<max(target.length/1000,1e-7) else remote).append(poly)
  coarse=union_all(selected)
  if coarse.is_empty:coarse=owner;remote=[]
  scope=coarse
 # Corrections have a local window; normal world detail/culling remains in use
 # when the user pans beyond it, including the distant coasts of neighbours.
 xmin,ymin,xmax,ymax=union_all([scope,target]).bounds;margin=max(xmax-xmin,ymax-ymin)*.12
 window=box(xmin-margin,ymin-margin,xmax+margin,ymax+margin)
 detailed=union_all([target,others])
 candidates=[];neighbour_shapes=[]
 for value in world:
  if value in owners:continue
  g=near(value['shape'])
  if g.intersects(window) and (g.distance(coarse)<2e-8 or g.intersects(detailed)):
   candidates.append(value);neighbour_shapes.append(g)
 gaps=gap_parts(coarse,detailed,neighbour_shapes,window)
 corrected=[make_valid(g.difference(detailed).union(gap)).buffer(0) for g,gap in zip(neighbour_shapes,gaps)]
 if active is not None:
  local=gap_land(active,target,union_all([others,*neighbour_shapes]),max(2e-8,.05/parent['mapReference']['scale']))
  corrected.append(make_valid(others.union(local).difference(target)).buffer(0))
 corrected.extend(remote)
 extra=union_all(corrected).intersection(window)
 extra_border=union_all([g.boundary for g in corrected if not g.is_empty]).difference(target).intersection(window)
 patches[info['id']]={'hiddenWorldNames':[w['name'] for w in owners+candidates], 'land':svg(extra), 'borders':svg(extra_border),'target':svg(target),'window':[window.bounds[0],window.bounds[1],window.bounds[2]-window.bounds[0],window.bounds[3]-window.bounds[1]]}
 audit.append({'id':info['id'],'count':len(shapes),'context_owner':[w['name'] for w in owners],'parent_scope':active is not None,'target_geometry_changed':False,'target_unit':info.get('subdivisionLabel') or info['unit'],'edition':info.get('edition'),'context_added_area':extra.area})
 checkpoint[info['id']]={'signature':signature,'patch':patches[info['id']],'audit':audit[-1]}
 if len(patches)%10==0:cachefile.write_text(json.dumps(checkpoint,separators=(',',':')))
 print(info['id'],len(shapes),flush=True)
cachefile.write_text(json.dumps(checkpoint,separators=(',',':')))
rawfolder=ROOT/'.build/map-alignment-raw';rawfolder.mkdir(parents=True,exist_ok=True)
for id,patch in patches.items():
 data=json.loads((ROOT/f'Content/Boards/{id}.json').read_text());ref=data['mapReference']
 def project(path):
  tokens=re.findall(r'[MLZ]|[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?',path);out=[];index=0
  while index<len(tokens):
   if tokens[index].isalpha():out.append(tokens[index]);index+=1;continue
   x=float(tokens[index])*ref['scale']+ref['x'];y=float(tokens[index+1])*ref['scale']+ref['y'];index+=2
   out.append(f'{x:.5f},{y:.5f}')
  return ''.join(out)
 packed={'period':ref['scale'],'hiddenWorldNames':patch['hiddenWorldNames'],'window':[patch['window'][0]*ref['scale']+ref['x'],patch['window'][1]*ref['scale']+ref['y'],patch['window'][2]*ref['scale'],patch['window'][3]*ref['scale']],**{key:project(patch[key]) for key in ['land','borders','target']}}
 (rawfolder/f'{id}.json').write_text(json.dumps(packed,separators=(',',':')))
folder=ROOT/'Content/MapAlignment';folder.mkdir(exist_ok=True)
subprocess.run(['xcrun','swift',str(ROOT/'Tools/pack-map-alignment.swift'),str(rawfolder),str(folder)],check=True)
(folder/'index.json').write_text(json.dumps({'ids':sorted(patches),'coordinateSpace':'board','compression':'LZFSE'},separators=(',',':')))
legacy=ROOT/'Content/map-alignment.json'
if legacy.exists():legacy.unlink()
(ROOT/'Tools/GeographyInputs/map-alignment-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('Aligned',len(patches),'subdivision contexts')
