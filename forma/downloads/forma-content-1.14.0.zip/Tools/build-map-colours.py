"""Derive stable four-colour assignments from shared map borders (offline). Requires Shapely 2.x."""
import json,re,math,time,sys
sys.setrecursionlimit(20000)
from pathlib import Path
from collections import defaultdict
from shapely.geometry import Polygon, box
from shapely import make_valid, union_all
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1]
TOKEN=re.compile(r'[MmLlHhVvZz]|-?\d*\.?\d+(?:[eE][-+]?\d+)?')
def geometry(path):
 t=TOKEN.findall(path); rings=[]; ring=[];i=0;cmd=None;x=y=0
 def finish():
  if len(ring)>2:
   p=make_valid(Polygon(ring)).buffer(0)
   if not p.is_empty:
    signed=sum(ring[k][0]*ring[(k+1)%len(ring)][1]-ring[(k+1)%len(ring)][0]*ring[k][1] for k in range(len(ring)))
    rings.append((p,signed))
 while i<len(t):
  if t[i].isalpha():
   cmd=t[i];i+=1
   if cmd.upper()=='Z':finish();ring=[];continue
  if cmd.upper() in ('M','L'):
   a,b=float(t[i]),float(t[i+1]);i+=2
   if cmd.islower():a+=x;b+=y
   x,y=a,b
   if cmd.upper()=='M':
    if ring:finish();ring=[]
    cmd='l' if cmd.islower() else 'L'
   ring.append((x,y))
  elif cmd.upper()=='H':
   a=float(t[i]);i+=1;x=a+x if cmd.islower() else a;ring.append((x,y))
  elif cmd.upper()=='V':
   a=float(t[i]);i+=1;y=a+y if cmd.islower() else a;ring.append((x,y))
  else:raise ValueError(cmd)
 if ring:finish()
 if not rings:return None
 sign=max(rings,key=lambda pair:abs(pair[1]))[1]>0
 value=union_all([p for p,a in rings if (a>0)==sign])
 holes=[p for p,a in rings if (a>0)!=sign]
 if holes:value=value.difference(union_all(holes))
 return make_valid(value).buffer(0).simplify(0.015, preserve_topology=True)
edges=set();nodes=set();cache={};boardcount=0
for path in sorted((ROOT/'Content/Boards').glob('*.json')):
 d=json.loads(path.read_text())
 if d['info']['domain']!='geography' or d['info']['type']=='points':continue
 shapes=[];ids=[]
 for item in d['items']:
  if not item.get('path'):continue
  key=item['path']
  if key not in cache:cache[key]=geometry(key)
  g=cache[key]
  if g is None or g.is_empty:continue
  shapes.append(g);ids.append(item['id']);nodes.add(item['id'])
 if not shapes:continue
 tree=STRtree(shapes)
 # Geometry is in a 900x640 board; this tolerance bridges rounded shared coordinates.
 eps=0.035
 for i,g in enumerate(shapes):
  for j in tree.query(box(g.bounds[0]-eps,g.bounds[1]-eps,g.bounds[2]+eps,g.bounds[3]+eps)):
   j=int(j)
   if j<=i or ids[i]==ids[j]:continue
   other=shapes[j]
   shared=g.boundary.intersection(other.boundary).length
   if shared>eps or (g.distance(other)<eps and g.boundary.intersection(other.boundary.buffer(eps, quad_segs=1)).length>eps*8):
    edges.add(tuple(sorted((ids[i],ids[j]))))
 boardcount+=1
 if boardcount%10==0:print('boards',boardcount,'edges',len(edges),flush=True)
graph=defaultdict(set)
for a,b in edges:graph[a].add(b);graph[b].add(a)
parts={}
colours={'USA':0,'GRL':1}
# DSATUR, with backtracking only within each connected component.
remaining=set(nodes)-set(colours); calls=0
while remaining:
 start=min(remaining);component={start};todo=[start]
 while todo:
  a=todo.pop()
  for b in graph[a]:
   if b not in component:component.add(b);todo.append(b)
 uncoloured=component-set(colours)
 def solve():
  global calls
  calls+=1
  if not uncoloured:return True
  node=max(uncoloured,key=lambda v:(len({colours[n] for n in graph[v] if n in colours}),len(graph[v]),v))
  used={colours[n] for n in graph[node] if n in colours}
  uncoloured.remove(node)
  # Rotate preference deterministically, keeping every palette colour in use.
  pref=sum(node.encode())%4
  for c in [(pref+i)%4 for i in range(4)]:
   if c in used:continue
   colours[node]=c
   if solve():return True
  colours.pop(node,None);uncoloured.add(node);return False
 if not solve():
  # Disconnected municipalities (notably Liechtenstein's exclaves) are not
  # a planar region graph. Colour their actual connected shapes separately.
  source=next((json.loads(p.read_text()) for p in sorted((ROOT/'Content/Boards').glob('*.json')) if component.issubset({i['id'] for i in json.loads(p.read_text())['items']})),None)
  if source is None:raise RuntimeError('No source for disconnected component')
  original={i['id']:i for i in source['items'] if i['id'] in component}
  pieces=[];pieceids=[]
  for ident,item in original.items():
   g=geometry(item['path']);polys=sorted(list(g.geoms) if g.geom_type=='MultiPolygon' else [g],key=lambda p:-p.area)
   for index,poly in enumerate(polys):pieces.append(poly);pieceids.append(f'{ident}#{index}')
  if len(pieces)==len(component):raise RuntimeError('Non-planar connected geometry: '+str(sorted(component)))
  edges={edge for edge in edges if not (set(edge)&component)}
  for ident in component:graph.pop(ident,None);colours.pop(ident,None)
  for i,g in enumerate(pieces):
   for j,other in enumerate(pieces[i+1:],i+1):
    if g.distance(other)<eps and (g.boundary.intersection(other.boundary).length>eps or g.boundary.intersection(other.boundary.buffer(eps,quad_segs=1)).length>eps*8):
     a,b=pieceids[i],pieceids[j];graph[a].add(b);graph[b].add(a);edges.add(tuple(sorted((a,b))))
  parts.update({key:(poly,original[key.split('#')[0]]['id']) for key,poly in zip(pieceids,pieces)})
  remaining-=component;remaining.update(pieceids)
  print('Colouring disconnected pieces for',source['info']['id'],len(pieces),flush=True)
  continue
 remaining-=component
assert all(colours[a]!=colours[b] for a,b in edges)
overrides={}
for key,(poly,ident) in parts.items():
 if key.endswith('#0'):colours[ident]=colours[key]
 coords=lambda ring:'M'+'L'.join(f'{x:.5f} {y:.5f}' for x,y in ring.coords)+'Z'
 overrides.setdefault(ident,[]).append({'path':coords(poly.exterior)+''.join(coords(ring) for ring in poly.interiors),'index':colours[key]})
(ROOT/'Content/map-colour-parts.json').write_text(json.dumps(overrides,separators=(',',':'))+'\n')
(ROOT/'Content/map-colours.json').write_text(json.dumps(dict(sorted(colours.items())),separators=(',',':'))+'\n')
out=ROOT/'Tools/GeographyInputs/map-adjacency.json';out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps({'tolerance':eps,'boards':boardcount,'edges':sorted(edges)},separators=(',',':'))+'\n')
print('DONE',boardcount,'boards',len(nodes),'targets',len(edges),'borders',calls,'search steps',flush=True)
